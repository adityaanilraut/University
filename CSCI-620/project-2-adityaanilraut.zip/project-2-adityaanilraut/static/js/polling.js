// AJAX polling for dynamic updates
let pollInterval;
let lastGameUpdate = null;

// Start polling when page loads
document.addEventListener('DOMContentLoaded', function() {
    startPolling();
});

function startPolling() {
    // Poll every 1 second
    pollInterval = setInterval(pollForUpdates, 1000);
}

function stopPolling() {
    if (pollInterval) {
        clearInterval(pollInterval);
        pollInterval = null;
    }
}

function pollForUpdates() {
    // Check if we're on a game page or new game page
    const gameIdElement = document.getElementById('game-id');
    const isNewGamePage = document.getElementById('new-game-page');
    
    if (gameIdElement) {
        // Poll for game state updates
        pollGameState(gameIdElement.textContent);
    } else if (isNewGamePage) {
        // Poll for new game updates (available players, challenges)
        pollNewGameUpdates();
    }
}

function pollGameState(gameId) {
    fetch(`/api/game-state/${gameId}/`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Error polling game state:', data.error);
                return;
            }
            
            // Check if game has ended
            if (data.status === 'completed') {
                stopPolling();
                showGameEndMessage(data);
                return;
            }
            
            // Check if opponent has moved (updated_at changed)
            const currentUpdate = data.updated_at;
            if (lastGameUpdate && lastGameUpdate !== currentUpdate) {
                // Opponent moved, reload page
                window.location.href = '/';
            }
            lastGameUpdate = currentUpdate;
            
            // Update turn indicator
            updateTurnIndicator(data);
        })
        .catch(error => {
            console.error('Error polling game state:', error);
        });
}

function pollNewGameUpdates() {
    // Poll for available players
    fetch('/api/available-players/')
        .then(response => response.json())
        .then(data => {
            if (data.players) {
                updateAvailablePlayers(data.players);
            }
        })
        .catch(error => {
            console.error('Error polling available players:', error);
        });
    
    // Poll for challenges
    fetch('/api/challenges/')
        .then(response => response.json())
        .then(data => {
            if (data.challenges) {
                updateChallenges(data.challenges);
            }
        })
        .catch(error => {
            console.error('Error polling challenges:', error);
        });
}

function updateAvailablePlayers(players) {
    const playersList = document.getElementById('available-players');
    if (!playersList) return;
    
    playersList.innerHTML = '';
    
    if (players.length === 0) {
        playersList.innerHTML = '<p class="text-muted">No players available</p>';
        return;
    }
    
    players.forEach(player => {
        const playerElement = document.createElement('div');
        playerElement.className = 'list-group-item d-flex justify-content-between align-items-center';
        playerElement.innerHTML = `
            <span>${player.username}</span>
            <button class="btn btn-sm btn-primary challenge-btn" data-player-id="${player.id}">
                Challenge
            </button>
        `;
        playersList.appendChild(playerElement);
    });
    
    // Add event listeners for challenge buttons
    document.querySelectorAll('.challenge-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const playerId = this.getAttribute('data-player-id');
            sendChallenge(playerId);
        });
    });
}

function updateChallenges(challenges) {
    const challengesList = document.getElementById('pending-challenges');
    if (!challengesList) return;
    
    challengesList.innerHTML = '';
    
    if (challenges.length === 0) {
        challengesList.innerHTML = '<p class="text-muted">No pending challenges</p>';
        return;
    }
    
    challenges.forEach(challenge => {
        const challengeElement = document.createElement('div');
        challengeElement.className = 'list-group-item';
        challengeElement.innerHTML = `
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <strong>${challenge.challenger}</strong> challenges you
                    <small class="text-muted d-block">${new Date(challenge.created_at).toLocaleTimeString()}</small>
                </div>
                <div>
                    <button class="btn btn-sm btn-success me-1 accept-challenge" data-challenge-id="${challenge.id}">
                        Accept
                    </button>
                    <button class="btn btn-sm btn-danger decline-challenge" data-challenge-id="${challenge.id}">
                        Decline
                    </button>
                </div>
            </div>
        `;
        challengesList.appendChild(challengeElement);
    });
    
    // Add event listeners for challenge response buttons
    document.querySelectorAll('.accept-challenge').forEach(btn => {
        btn.addEventListener('click', function() {
            const challengeId = this.getAttribute('data-challenge-id');
            respondToChallenge(challengeId, 'accept');
        });
    });
    
    document.querySelectorAll('.decline-challenge').forEach(btn => {
        btn.addEventListener('click', function() {
            const challengeId = this.getAttribute('data-challenge-id');
            respondToChallenge(challengeId, 'decline');
        });
    });
}

function sendChallenge(playerId) {
    fetch('/api/send-challenge/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({
            opponent_id: playerId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Challenge sent!', 'success');
        } else {
            showNotification(data.error || 'Failed to send challenge', 'error');
        }
    })
    .catch(error => {
        console.error('Error sending challenge:', error);
        showNotification('Failed to send challenge', 'error');
    });
}

function respondToChallenge(challengeId, response) {
    fetch('/api/respond-challenge/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({
            challenge_id: challengeId,
            response: response
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            if (response === 'accept' && data.game_id) {
                showNotification('Challenge accepted! Starting game...', 'success');
                setTimeout(() => {
                    window.location.href = `/game/${data.game_id}/`;
                }, 1000);
            } else {
                showNotification(data.message, 'success');
            }
        } else {
            showNotification(data.error || 'Failed to respond to challenge', 'error');
        }
    })
    .catch(error => {
        console.error('Error responding to challenge:', error);
        showNotification('Failed to respond to challenge', 'error');
    });
}

function updateTurnIndicator(gameState) {
    const turnIndicator = document.getElementById('turn-indicator');
    if (!turnIndicator) return;
    
    const isCurrentTurn = gameState.is_current_turn;
    const currentTurn = gameState.current_turn;
    
    turnIndicator.textContent = `${currentTurn.charAt(0).toUpperCase() + currentTurn.slice(1)}'s turn`;
    turnIndicator.className = `badge ${isCurrentTurn ? 'bg-success' : 'bg-secondary'}`;
}

function showGameEndMessage(gameState) {
    let message = '';
    if (gameState.outcome === 'checkmate') {
        message = `Checkmate! ${gameState.winner} wins!`;
    } else if (gameState.outcome === 'stalemate') {
        message = 'Stalemate! Game is a draw.';
    } else if (gameState.outcome === 'resignation') {
        message = `${gameState.winner} wins by resignation!`;
    } else {
        message = 'Game ended.';
    }
    
    showNotification(message, 'info');
    
    // Redirect to home after 3 seconds
    setTimeout(() => {
        window.location.href = '/';
    }, 3000);
}

function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}
