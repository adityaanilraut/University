[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/bXdqKfYN)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-2972f46106e565e64193e422d61a12cf1da4916b45550586e14ef0a7c637dd04.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=21133855)
# 620-P2-Starter
- Open CodeSpaces for this repo under Code, in the Codespaces tab. Click the green button to create and open the new Codespace.
- This should open a new browser tab containing a VSCode window.  After a few minutes, you should see a command line prompt at the bottom, in the terminal window.
- Next, run the following command to create a new Django project for Project 2:
```bash
django-admin startproject project2
```
- Next, cd into the new project2 directory:
```bash
cd project2
```
- Next, run the following command to create a new Django applicaton within your Django project:
```bash
python manage.py startapp app1
```
- Next, review the posted notes for creating a basic "Hello World!" application (within Canvas, under Modules > Lectures > Week 3).
- Start your Django project:
```bash
python manage.py runserver
```
- A new browser tab should open displaying your Hello World! content.
- Hit ctrl-c to exit the runserver command
- Commit and push your changes:
```bash
cd ..
git add .
git commit -m "Initial commit"
git push
```
- Note: If you get a write access error when attempting to push to github, you may need to create your own fork of the repo, clone it, do your pushes to it, and then submit a Pull Request into your original repo to submit your work for grading.
- It is very important that you do regular commits and pushes to avoid losing any work-in-progress.
- Proceed with implementing the rest of the Project 2 features.
- Note: Codespaces will timeout after a period of inactivity.  If this happens, you can restore your previous session by reopening your codespace within the github web interface, in the same place you created your codespace.
- Tip:  If you need to prevent your Codespace session timing out, you can run this command to keep it alive:
```bash
while true; do echo "Preventing timeout..."; sleep 60; done
```

