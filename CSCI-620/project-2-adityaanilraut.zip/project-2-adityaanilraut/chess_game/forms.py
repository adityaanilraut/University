from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class UserRegistrationForm(UserCreationForm):
    """Custom user registration form"""
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=30, required=True)
    last_name = forms.CharField(max_length=30, required=True)
    
    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')
    
    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        if commit:
            user.save()
        return user


class MoveForm(forms.Form):
    """Form for chess move input"""
    from_square = forms.CharField(
        max_length=2,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'e2',
            'style': 'text-transform: lowercase;'
        }),
        label='From (e.g., e2)'
    )
    to_square = forms.CharField(
        max_length=2,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'e4',
            'style': 'text-transform: lowercase;'
        }),
        label='To (e.g., e4)'
    )
    
    def clean_from_square(self):
        from_square = self.cleaned_data.get('from_square', '').lower()
        if len(from_square) != 2:
            raise forms.ValidationError("Square must be 2 characters (e.g., 'e2')")
        if from_square[0] not in 'abcdefgh' or from_square[1] not in '12345678':
            raise forms.ValidationError("Invalid square format. Use letters a-h and numbers 1-8")
        return from_square
    
    def clean_to_square(self):
        to_square = self.cleaned_data.get('to_square', '').lower()
        if len(to_square) != 2:
            raise forms.ValidationError("Square must be 2 characters (e.g., 'e4')")
        if to_square[0] not in 'abcdefgh' or to_square[1] not in '12345678':
            raise forms.ValidationError("Invalid square format. Use letters a-h and numbers 1-8")
        return to_square
    
    def clean(self):
        cleaned_data = super().clean()
        from_square = cleaned_data.get('from_square')
        to_square = cleaned_data.get('to_square')
        
        if from_square and to_square and from_square == to_square:
            raise forms.ValidationError("From and to squares cannot be the same")
        
        return cleaned_data
