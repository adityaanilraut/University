from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.utils import timezone
from django.db.models import Q
import chess
import json

from .models import Game, Challenge, Move
from .forms import UserRegistrationForm, MoveForm
from .utils import (
    get_logged_in_users_excluding_current,
    get_available_players,
    board_to_dict,
    board_to_dict_flipped,
    validate_move_notation,
    get_user_game_history
)


def home_view(request):
    """Main home view - shows login, new game, or active game based on user state"""
    if not request.user.is_authenticated:
        # Show login page
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.error(request, 'Invalid username or password.')
        return render(request, 'chess_game/home.html')
    
    # User is authenticated - check for active game
    try:
        active_game = Game.objects.filter(
            Q(white_player=request.user) | Q(black_player=request.user),
            status='active'
        ).first()
        
        if active_game:
            # Show active game
            return game_view(request, active_game.id)
        else:
            # Show new game screen
            return new_game_view(request)
    except Exception as e:
        # Show new game screen if there's any issue
        return new_game_view(request)


def join_view(request):
    """User registration view"""
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('home')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'chess_game/join.html', {'form': form})


@login_required
def logout_view(request):
    """User logout view"""
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('home')


@login_required
def new_game_view(request):
    """New game screen with available players and game history"""
    available_players = get_available_players(request)
    game_history = get_user_game_history(request.user)
    
    # Get pending challenges
    pending_challenges = Challenge.objects.filter(
        opponent=request.user,
        status='pending'
    )
    
    # Get challenges made by current user
    my_challenges = Challenge.objects.filter(
        challenger=request.user,
        status='pending'
    )
    
    context = {
        'available_players': available_players,
        'game_history': game_history,
        'pending_challenges': pending_challenges,
        'my_challenges': my_challenges,
    }
    
    return render(request, 'chess_game/new_game.html', context)


@login_required
def game_view(request, game_id):
    """Active game view with chessboard"""
    game = get_object_or_404(Game, id=game_id)
    
    # Check if user is part of this game
    if game.white_player != request.user and game.black_player != request.user:
        messages.error(request, 'You are not authorized to view this game.')
        return redirect('home')
    
    # Determine if current user is white or black
    is_white_player = (game.white_player == request.user)
    is_current_turn = (
        (is_white_player and game.current_turn == 'white') or
        (not is_white_player and game.current_turn == 'black')
    )
    
    # Get board representation
    board = game.get_board()
    if is_white_player:
        board_dict = board_to_dict(board)
    else:
        board_dict = board_to_dict_flipped(board)
    
    # Move form
    move_form = MoveForm()
    
    context = {
        'game': game,
        'board_dict': board_dict,
        'is_white_player': is_white_player,
        'is_current_turn': is_current_turn,
        'move_form': move_form,
        'opponent': game.black_player if is_white_player else game.white_player,
    }
    
    return render(request, 'chess_game/game.html', context)


@login_required
def make_move_view(request, game_id):
    """Handle chess move submission"""
    game = get_object_or_404(Game, id=game_id)
    
    # Check if user is part of this game
    if game.white_player != request.user and game.black_player != request.user:
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    
    if request.method == 'POST':
        form = MoveForm(request.POST)
        if form.is_valid():
            from_square = form.cleaned_data['from_square']
            to_square = form.cleaned_data['to_square']
            
            # Validate move with python-chess
            board = game.get_board()
            
            try:
                # Create UCI move notation
                from_square_uci = chess.parse_square(from_square)
                to_square_uci = chess.parse_square(to_square)
                move = chess.Move(from_square_uci, to_square_uci)
                
                # Validate and make move
                if move in board.legal_moves:
                    board.push(move)
                    
                    # Save move to database
                    move_obj = Move.objects.create(
                        game=game,
                        player=request.user,
                        move_notation=f"{from_square}{to_square}",
                        board_state_after=board.fen(),
                        move_number=game.moves.count() + 1
                    )
                    
                    # Update game state
                    game.board_state = board.fen()
                    game.current_turn = 'black' if game.current_turn == 'white' else 'white'
                    game.update_board_state(board.fen())
                    
                    return JsonResponse({'success': True, 'message': 'Move made successfully'})
                else:
                    return JsonResponse({'error': 'Invalid move'}, status=400)
                    
            except (ValueError, IndexError):
                return JsonResponse({'error': 'Invalid move format'}, status=400)
        else:
            return JsonResponse({'error': 'Invalid form data'}, status=400)
    
    return JsonResponse({'error': 'Method not allowed'}, status=405)


@login_required
def resign_view(request, game_id):
    """Handle game resignation"""
    game = get_object_or_404(Game, id=game_id)
    
    # Check if user is part of this game
    if game.white_player != request.user and game.black_player != request.user:
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    
    if game.status != 'active':
        return JsonResponse({'error': 'Game is not active'}, status=400)
    
    # Set game as completed
    game.status = 'completed'
    game.outcome = 'resignation'
    game.winner = game.black_player if game.white_player == request.user else game.white_player
    game.save()
    
    return JsonResponse({'success': True, 'message': 'Game resigned successfully'})


def rules_view(request):
    """Chess rules page - accessible to all users"""
    return render(request, 'chess_game/rules.html')


def about_view(request):
    """About page - accessible to all users"""
    return render(request, 'chess_game/about.html')


@login_required
def history_view(request):
    """Game history page for logged-in users"""
    game_history = get_user_game_history(request.user)
    context = {'game_history': game_history}
    return render(request, 'chess_game/history.html', context)


# AJAX API Endpoints

@login_required
@require_http_methods(["GET"])
def api_available_players(request):
    """API endpoint to get available players"""
    available_players = get_available_players(request)
    players_data = [{'id': player.id, 'username': player.username} for player in available_players]
    return JsonResponse({'players': players_data})


@login_required
@require_http_methods(["GET"])
def api_challenges(request):
    """API endpoint to get pending challenges"""
    pending_challenges = Challenge.objects.filter(
        opponent=request.user,
        status='pending'
    )
    challenges_data = [
        {
            'id': challenge.id,
            'challenger': challenge.challenger.username,
            'created_at': challenge.created_at.isoformat()
        }
        for challenge in pending_challenges
    ]
    return JsonResponse({'challenges': challenges_data})


@login_required
@require_http_methods(["POST"])
@csrf_exempt
def api_send_challenge(request):
    """API endpoint to send a challenge"""
    try:
        data = json.loads(request.body)
        opponent_id = data.get('opponent_id')
        
        opponent = get_object_or_404(request.user.__class__, id=opponent_id)
        
        # Check if challenge already exists
        existing_challenge = Challenge.objects.filter(
            challenger=request.user,
            opponent=opponent,
            status='pending'
        ).first()
        
        if existing_challenge:
            return JsonResponse({'error': 'Challenge already sent'}, status=400)
        
        # Create new challenge
        challenge = Challenge.objects.create(
            challenger=request.user,
            opponent=opponent,
            status='pending'
        )
        
        return JsonResponse({'success': True, 'challenge_id': challenge.id})
        
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)


@login_required
@require_http_methods(["POST"])
@csrf_exempt
def api_respond_challenge(request):
    """API endpoint to accept or decline a challenge"""
    try:
        data = json.loads(request.body)
        challenge_id = data.get('challenge_id')
        response = data.get('response')  # 'accept' or 'decline'
        
        challenge = get_object_or_404(Challenge, id=challenge_id, opponent=request.user)
        
        if challenge.status != 'pending':
            return JsonResponse({'error': 'Challenge already responded to'}, status=400)
        
        if response == 'accept':
            challenge.status = 'accepted'
            challenge.save()
            
            # Create new game
            game = Game.objects.create(
                white_player=challenge.challenger,
                black_player=challenge.opponent,
                current_turn='white'
            )
            
            return JsonResponse({
                'success': True,
                'message': 'Challenge accepted',
                'game_id': game.id
            })
        elif response == 'decline':
            challenge.status = 'declined'
            challenge.save()
            return JsonResponse({'success': True, 'message': 'Challenge declined'})
        else:
            return JsonResponse({'error': 'Invalid response'}, status=400)
            
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=400)


@login_required
@require_http_methods(["GET"])
def api_game_state(request, game_id):
    """API endpoint to get current game state"""
    game = get_object_or_404(Game, id=game_id)
    
    # Check if user is part of this game
    if game.white_player != request.user and game.black_player != request.user:
        return JsonResponse({'error': 'Unauthorized'}, status=403)
    
    is_white_player = (game.white_player == request.user)
    is_current_turn = (
        (is_white_player and game.current_turn == 'white') or
        (not is_white_player and game.current_turn == 'black')
    )
    
    return JsonResponse({
        'game_id': game.id,
        'status': game.status,
        'current_turn': game.current_turn,
        'is_current_turn': is_current_turn,
        'outcome': game.outcome,
        'winner': game.winner.username if game.winner else None,
        'updated_at': game.updated_at.isoformat()
    })