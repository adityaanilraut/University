from django.urls import path
from . import views

urlpatterns = [
    # Main views
    path('', views.home_view, name='home'),
    path('join/', views.join_view, name='join'),
    path('logout/', views.logout_view, name='logout'),
    path('rules/', views.rules_view, name='rules'),
    path('about/', views.about_view, name='about'),
    path('history/', views.history_view, name='history'),
    
    # Game views
    path('game/<int:game_id>/', views.game_view, name='game'),
    path('game/<int:game_id>/move/', views.make_move_view, name='make_move'),
    path('game/<int:game_id>/resign/', views.resign_view, name='resign'),
    
    # API endpoints
    path('api/available-players/', views.api_available_players, name='api_available_players'),
    path('api/challenges/', views.api_challenges, name='api_challenges'),
    path('api/send-challenge/', views.api_send_challenge, name='api_send_challenge'),
    path('api/respond-challenge/', views.api_respond_challenge, name='api_respond_challenge'),
    path('api/game-state/<int:game_id>/', views.api_game_state, name='api_game_state'),
]
