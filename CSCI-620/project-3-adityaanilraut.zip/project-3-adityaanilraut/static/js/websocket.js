// WebSocket client for real-time chess game updates

// Game WebSocket Management
class GameWebSocket {
    constructor(gameId) {
        this.gameId = gameId;
        this.ws = null;
        this.reloadScheduled = false;
        this.isInitialConnection = true;
        this.lastBoardState = null;
        this.connect();
    }
    
    connect() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/game/${this.gameId}/`;
        
        this.ws = new WebSocket(wsUrl);
        
        this.ws.onopen = () => {
            console.log('Game WebSocket connected');
            // Reset initial connection flag after a short delay
            setTimeout(() => {
                this.isInitialConnection = false;
            }, 1000);
        };
        
        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
        };
        
        this.ws.onclose = () => {
            console.log('Game WebSocket disconnected');
            // Only attempt to reconnect if we're not reloading and not initial connection
            if (!this.reloadScheduled && !this.isInitialConnection) {
                setTimeout(() => this.connect(), 3000);
            }
        };
        
        this.ws.onerror = (error) => {
            console.error('Game WebSocket error:', error);
        };
    }
    
    handleMessage(data) {
        if (data.type === 'game_state') {
            this.updateGameState(data.data);
        } else if (data.type === 'error') {
            showNotification(data.message, 'error');
        }
    }
    
    updateGameState(gameState) {
        // Check if game has ended
        if (gameState.status === 'completed') {
            this.showGameEndMessage(gameState);
            return;
        }
        
        // Don't reload on initial connection - board is already up to date
        if (this.isInitialConnection) {
            this.lastBoardState = gameState.board_state;
            return;
        }
        
        // Only reload if board state has changed (indicating a move was made)
        if (gameState.board_state && gameState.board_state !== this.lastBoardState) {
            this.lastBoardState = gameState.board_state;
            
            // Update turn indicator
            const turnIndicator = document.getElementById('turn-indicator');
            if (turnIndicator) {
                turnIndicator.textContent = `${gameState.current_turn.charAt(0).toUpperCase() + gameState.current_turn.slice(1)}'s turn`;
                turnIndicator.className = `badge ${gameState.is_current_turn ? 'bg-success' : 'bg-secondary'}`;
            }
            
            // Reload page after a short delay to show updated board
            // Use a flag to prevent multiple reloads
            if (!this.reloadScheduled) {
                this.reloadScheduled = true;
                showNotification('Board updated! Refreshing...', 'info');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            }
        } else {
            // Board state hasn't changed, just update the UI elements
            const turnIndicator = document.getElementById('turn-indicator');
            if (turnIndicator) {
                turnIndicator.textContent = `${gameState.current_turn.charAt(0).toUpperCase() + gameState.current_turn.slice(1)}'s turn`;
                turnIndicator.className = `badge ${gameState.is_current_turn ? 'bg-success' : 'bg-secondary'}`;
            }
        }
    }
    
    showGameEndMessage(gameState) {
        let message = '';
        if (gameState.outcome === 'checkmate') {
            message = `Checkmate! ${gameState.winner} wins!`;
        } else if (gameState.outcome === 'stalemate') {
            message = 'Stalemate! Game is a draw.';
        } else if (gameState.outcome === 'resignation') {
            message = `${gameState.winner} wins by resignation!`;
        } else {
            message = 'Game ended.';
        }
        
        showNotification(message, 'info');
        
        // Reload page after 3 seconds
        setTimeout(() => {
            window.location.href = '/';
        }, 3000);
    }
    
    sendMove(fromSquare, toSquare) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'new_move',
                from_square: fromSquare,
                to_square: toSquare
            }));
        }
    }
    
    sendResign() {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'game_action',
                action: 'resign'
            }));
        }
    }
    
    disconnect() {
        if (this.ws) {
            this.ws.close();
        }
    }
}

// Lobby WebSocket Management
class LobbyWebSocket {
    constructor() {
        this.ws = null;
        this.connect();
    }
    
    connect() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}/ws/lobby/`;
        
        this.ws = new WebSocket(wsUrl);
        
        this.ws.onopen = () => {
            console.log('Lobby WebSocket connected');
        };
        
        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
        };
        
        this.ws.onclose = () => {
            console.log('Lobby WebSocket disconnected');
            // Attempt to reconnect after 3 seconds
            setTimeout(() => this.connect(), 3000);
        };
        
        this.ws.onerror = (error) => {
            console.error('Lobby WebSocket error:', error);
        };
    }
    
    handleMessage(data) {
        if (data.type === 'lobby_data') {
            this.updateLobby(data.data);
        } else if (data.type === 'new_game') {
            // Redirect to game
            showNotification('Challenge accepted! Starting game...', 'success');
            setTimeout(() => {
                window.location.href = `/game/${data.game_id}/`;
            }, 1000);
        } else if (data.type === 'challenge_sent') {
            showNotification(data.message, 'success');
        } else if (data.type === 'challenge_response') {
            showNotification(data.message, 'success');
        } else if (data.type === 'error') {
            showNotification(data.message, 'error');
        }
    }
    
    updateLobby(lobbyData) {
        this.updateAvailablePlayers(lobbyData.available_players);
        this.updateChallenges(lobbyData.pending_challenges);
    }
    
    updateAvailablePlayers(players) {
        const playersList = document.getElementById('available-players');
        if (!playersList) return;
        
        playersList.innerHTML = '';
        
        if (players.length === 0) {
            playersList.innerHTML = '<p class="text-muted">No players available</p>';
            return;
        }
        
        players.forEach(player => {
            const playerElement = document.createElement('div');
            playerElement.className = 'list-group-item d-flex justify-content-between align-items-center';
            playerElement.innerHTML = `
                <span>${player.username}</span>
                <button class="btn btn-sm btn-primary challenge-btn" data-player-id="${player.id}">
                    Challenge
                </button>
            `;
            playersList.appendChild(playerElement);
        });
        
        // Add event listeners for challenge buttons
        document.querySelectorAll('.challenge-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const playerId = this.getAttribute('data-player-id');
                lobbyWebSocket.sendChallenge(playerId);
            });
        });
    }
    
    updateChallenges(challenges) {
        const challengesList = document.getElementById('pending-challenges');
        if (!challengesList) return;
        
        challengesList.innerHTML = '';
        
        if (challenges.length === 0) {
            challengesList.innerHTML = '<p class="text-muted">No pending challenges</p>';
            return;
        }
        
        challenges.forEach(challenge => {
            const challengeElement = document.createElement('div');
            challengeElement.className = 'list-group-item';
            challengeElement.innerHTML = `
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <strong>${challenge.challenger}</strong> challenges you
                        <small class="text-muted d-block">${new Date(challenge.created_at).toLocaleTimeString()}</small>
                    </div>
                    <div>
                        <button class="btn btn-sm btn-success me-1 accept-challenge" data-challenge-id="${challenge.id}">
                            Accept
                        </button>
                        <button class="btn btn-sm btn-danger decline-challenge" data-challenge-id="${challenge.id}">
                            Decline
                        </button>
                    </div>
                </div>
            `;
            challengesList.appendChild(challengeElement);
        });
        
        // Add event listeners for challenge response buttons
        document.querySelectorAll('.accept-challenge').forEach(btn => {
            btn.addEventListener('click', function() {
                const challengeId = this.getAttribute('data-challenge-id');
                lobbyWebSocket.respondChallenge(challengeId, 'accept');
            });
        });
        
        document.querySelectorAll('.decline-challenge').forEach(btn => {
            btn.addEventListener('click', function() {
                const challengeId = this.getAttribute('data-challenge-id');
                lobbyWebSocket.respondChallenge(challengeId, 'decline');
            });
        });
    }
    
    sendChallenge(playerId) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'send_challenge',
                opponent_id: parseInt(playerId)
            }));
        }
    }
    
    respondChallenge(challengeId, response) {
        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify({
                type: 'respond_challenge',
                challenge_id: parseInt(challengeId),
                response: response
            }));
        }
    }
    
    disconnect() {
        if (this.ws) {
            this.ws.close();
        }
    }
}

// Global instances
let gameWebSocket = null;
let lobbyWebSocket = null;

// Initialize WebSockets when page loads
document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on a game page
    const gameIdElement = document.getElementById('game-id');
    if (gameIdElement) {
        const gameId = gameIdElement.textContent;
        gameWebSocket = new GameWebSocket(gameId);
    }
    
    // Check if we're on the lobby/new game page
    const isNewGamePage = document.getElementById('new-game-page');
    if (isNewGamePage) {
        lobbyWebSocket = new LobbyWebSocket();
    }
});

// Clean up WebSockets when page unloads
window.addEventListener('beforeunload', function() {
    if (gameWebSocket) {
        gameWebSocket.reloadScheduled = true; // Prevent reconnection attempts
        gameWebSocket.disconnect();
    }
    if (lobbyWebSocket) {
        lobbyWebSocket.disconnect();
    }
});

// Utility functions
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `alert alert-${type === 'error' ? 'danger' : type} alert-dismissible fade show position-fixed`;
    notification.style.top = '20px';
    notification.style.right = '20px';
    notification.style.zIndex = '9999';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

