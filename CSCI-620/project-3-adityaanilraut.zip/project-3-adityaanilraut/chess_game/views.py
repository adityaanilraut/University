from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

from .models import Game, Challenge
from .forms import UserRegistrationForm, MoveForm
from .utils import (
    get_available_players,
    board_to_dict,
    board_to_dict_flipped,
    get_user_game_history
)


def home_view(request):
    """Main home view - shows login, new game, or active game based on user state"""
    if not request.user.is_authenticated:
        # Show login page
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.error(request, 'Invalid username or password.')
        return render(request, 'chess_game/home.html')
    
    # User is authenticated - check for active game
    try:
        active_game = Game.objects.filter(
            Q(white_player=request.user) | Q(black_player=request.user),
            status='active'
        ).first()
        
        if active_game:
            # Redirect to active game
            return redirect('game', game_id=active_game.id)
        else:
            # Show new game screen
            return new_game_view(request)
    except Exception as e:
        # Show new game screen if there's any issue
        return new_game_view(request)


def join_view(request):
    """User registration view"""
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('home')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'chess_game/join.html', {'form': form})


@login_required
def logout_view(request):
    """User logout view"""
    # Get channel layer to notify lobby
    channel_layer = get_channel_layer()
    
    # Notify lobby that user is logging out
    if channel_layer:
        async_to_sync(channel_layer.group_send)(
            'lobby',
            {
                'type': 'lobby_update',
            }
        )
    
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('home')


@login_required
def new_game_view(request):
    """New game screen with available players and game history"""
    available_players = get_available_players(request.user)
    game_history = get_user_game_history(request.user)
    
    # Get pending challenges
    pending_challenges = Challenge.objects.filter(
        opponent=request.user,
        status='pending'
    )
    
    # Get challenges made by current user
    my_challenges = Challenge.objects.filter(
        challenger=request.user,
        status='pending'
    )
    
    context = {
        'available_players': available_players,
        'game_history': game_history,
        'pending_challenges': pending_challenges,
        'my_challenges': my_challenges,
    }
    
    return render(request, 'chess_game/new_game.html', context)


@login_required
def game_view(request, game_id):
    """Active game view with chessboard"""
    game = get_object_or_404(Game, id=game_id)
    
    # Check if user is part of this game
    if game.white_player != request.user and game.black_player != request.user:
        messages.error(request, 'You are not authorized to view this game.')
        return redirect('home')
    
    # Determine if current user is white or black
    is_white_player = (game.white_player == request.user)
    is_current_turn = (
        (is_white_player and game.current_turn == 'white') or
        (not is_white_player and game.current_turn == 'black')
    )
    
    # Get board representation
    board = game.get_board()
    if is_white_player:
        board_dict = board_to_dict(board)
    else:
        board_dict = board_to_dict_flipped(board)
    
    # Move form
    move_form = MoveForm()
    
    context = {
        'game': game,
        'board_dict': board_dict,
        'is_white_player': is_white_player,
        'is_current_turn': is_current_turn,
        'move_form': move_form,
        'opponent': game.black_player if is_white_player else game.white_player,
    }
    
    return render(request, 'chess_game/game.html', context)



def rules_view(request):
    """Chess rules page - accessible to all users"""
    return render(request, 'chess_game/rules.html')


def about_view(request):
    """About page - accessible to all users"""
    return render(request, 'chess_game/about.html')


@login_required
def history_view(request):
    """Game history page for logged-in users"""
    game_history = get_user_game_history(request.user)
    context = {'game_history': game_history}
    return render(request, 'chess_game/history.html', context)