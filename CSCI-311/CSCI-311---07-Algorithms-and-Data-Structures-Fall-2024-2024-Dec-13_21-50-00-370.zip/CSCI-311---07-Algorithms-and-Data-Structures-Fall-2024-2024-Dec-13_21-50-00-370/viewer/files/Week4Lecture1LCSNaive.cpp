#include<iostream>
#include<algorithm>
#include<string.h>
using namespace std;
//Without using DP
//T(m,n)=T(m−1,n)+T(m,n−1)+c

int LCS(char X[], int m, char Y[], int n) {
    // Base Case
    if (m == 0 || n == 0) {
        return 0;
    }
    
    // If last characters are the same
    if (X[m - 1] == Y[n - 1]) {
        return 1 + LCS(X, m - 1, Y, n - 1);
    } else {
        // Otherwise, find the maximum of two cases:
        // 1) Exclude last character of X and find LCS of lengths m-1 and n
        // 2) Exclude last character of Y and find LCS of lengths m and n-1
        return max(LCS(X, m - 1, Y, n), LCS(X, m, Y, n - 1));
    }
}

int main() {
    char X[] = "AGGTAB";
    char Y[] = "GXTXAYB";
    int m = strlen(X);
    int n = strlen(Y);
    
    cout << "Length of LCS is " << LCS(X, m, Y, n) << endl;

    return 0;
}
