#include <algorithm>
#include <iostream>
using namespace std;

/*
<-----------non zero-------><----???????------><-000000000->
j is keeping track the start of the ?? 
i is keeping track of the start of the 00 
*/
void moveZeroesv3(int nums[], int n) {
    int i=n;
    int j=0;
    while(j<i)
    {
       if (nums[j]!=0)
       {
        j++;
       }
        else
        {
            int k=j+1;
            while(k<i)
            {
                nums[k-1]=nums[k];
                k=k+1;
            }
            //k=i;
            nums[i-1]=0;
            i=i-1;
        }
    }
    //j=i;
}


/*
<-----------non zero-------><-000000000-><----???????------>
At the very start: 
1. All the ?? i.e., unexplored array must be the entire array which means i=0
i.e. n-1-(i=0)+1 =n 

2. The non zero component of the array must be zero i.e., 
j-0+1 = 0 
j=-1

3. Now we know at the start, j=-1 and the i=0, this means that the area of the 0 region of the array must be
i-1-(j+1)+1= 
0-1-(-1+1)+1=
-1-0+1=0
which also confirms our expectation
*/
void moveZeroesv2(int nums[], int n) {
    int i=0;
    int j=-1;
    while(i<n)
    {
        if (nums[i]==0)
        {
            i=i+1;
        }
        else
        {
            swap(nums[j+1],nums[i]);
            j=j+1;
            i=i+1;
        }
        
    }
    //i=n;
}


void moveZeroes(int nums[], int n) {
    int i = 0, j = 0;
    while (i < n) {
        if (nums[i] != 0) {
            swap(nums[i], nums[j]);
            j++;
        }
        i++;
    }
}

int main()
{
    int b[]={7,1,0,5,3,0,0,1,2,0,0,8};
    moveZeroesv3(b,12);
    for (int e:b)
    {
        cout << e << " ";
    }

}