#include <iostream>
#include <algorithm>
using namespace std;

//T(A)=n×max i=1 to n of T(A−coins[i])+c
//T(A)=\sum_{i=1}^{n} (T(A−coins[i]))+c

const int INF = 1e9;  // A large value to represent infinity.

int coinChangeNaive(const int coins[], int numCoins, int amount) {
    // Base cases
    if (amount == 0) return 0;
    if (amount < 0) return INF;

    int minCoins = INF;

    for (int i = 0; i < numCoins; i++) {
        int res = coinChangeNaive(coins, numCoins, amount - coins[i]);
        if (res != INF) {
            minCoins = min(minCoins, res + 1);
        }
    }

    return minCoins;
}

int main() {
    int coins[] = {1, 2, 5};
    int numCoins = sizeof(coins) / sizeof(coins[0]);
    int amount = 6;
    int result = coinChangeNaive(coins, numCoins, amount);
    
    if (result != INF) {
        // Output: 3, as the minimum coins to make 11 are [5, 5, 1].
        cout << result << endl;
    } else {
        cout << "Not possible" << endl;
    }
    return 0;
}
