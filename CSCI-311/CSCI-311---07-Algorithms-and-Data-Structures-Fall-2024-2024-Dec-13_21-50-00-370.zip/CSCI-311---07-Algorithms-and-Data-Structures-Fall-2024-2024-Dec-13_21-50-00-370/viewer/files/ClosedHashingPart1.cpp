#include <iostream>
using namespace std;

class HashTable {
private:
    int* table;
    int capacity;
    int hash(int key) {
        return key % capacity;
    }

public:
    HashTable(int size) {
        capacity = size;
        table = new int[size];
        for(int i = 0; i < size; i++) {
            table[i] = -1; // -1 indicates an empty slot
        }
    }

    ~HashTable() {
        delete[] table;
    }

    // Linear probing
    bool insertLinear(int key) {
        int index = hash(key);
        int originalIndex = index;
        do {
            if (table[index] == -1) {
                table[index] = key;
                return true;
            }
            index = (index + 1) % capacity;
        } while (index != originalIndex);
        return false;
    }

    // Quadratic probing
    bool insertQuadratic(int key) {
        int index = hash(key);
        int i = 0;
        int originalIndex = index;
        do {
            if (table[index] == -1) {
                table[index] = key;
                return true;
            }
            i++;
            index = (originalIndex + i * i) % capacity;
        } while (index != originalIndex && i < capacity);
        return false;
    }

    void display() {
        for(int i = 0; i < capacity; i++) {
            if(table[i] != -1)
                cout << i << " => " << table[i] << endl;
            else
                cout << i << " => " << endl;
        }
    }
};

int main() {
    HashTable ht(10);

    // Demo with linear probing
    cout << "Inserting with linear probing:" << endl;
    ht.insertLinear(5);
    ht.insertLinear(15);
    ht.insertLinear(25);
    ht.display();

    // Clearing the table for quadratic probing demo
    HashTable ht2(10);

    // Demo with quadratic probing
    cout << "\nInserting with quadratic probing:" << endl;
    ht2.insertQuadratic(5);
    ht2.insertQuadratic(15);
    ht2.insertQuadratic(25);
    ht2.display();

    return 0;
}
