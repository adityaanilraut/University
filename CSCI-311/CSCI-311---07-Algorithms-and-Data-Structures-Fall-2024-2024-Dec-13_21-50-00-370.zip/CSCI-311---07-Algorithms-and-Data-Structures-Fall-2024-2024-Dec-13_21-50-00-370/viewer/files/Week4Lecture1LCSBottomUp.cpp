#include<iostream>
#include<algorithm>
#include <string.h>
using namespace std;
//Using DP but with bottom up. 
int LCS(char X[], int m, char Y[], int n) {
    int dp[m+1][n+1];
    
    // Base initialization
    for (int i = 0; i <= m; i++) {
        dp[i][0] = 0;
    }
    for (int j = 0; j <= n; j++) {
        dp[0][j] = 0;
    }
    
    // Fill dp[][] in bottom-up manner
    for (int i = 1; i <= m; i++) {
        for (int j = 1; j <= n; j++) {
            if (X[i-1] == Y[j-1]) {
                dp[i][j] = dp[i-1][j-1] + 1;
            } else {
                dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
            }
        }
    }
    
    return dp[m][n];
}

int main() {
    char X[] = "AGGTAB";
    char Y[] = "GXTXAYB";
    int m = strlen(X);
    int n = strlen(Y);
    
    cout << "Length of LCS is " << LCS(X, m, Y, n) << endl;

    return 0;
}
