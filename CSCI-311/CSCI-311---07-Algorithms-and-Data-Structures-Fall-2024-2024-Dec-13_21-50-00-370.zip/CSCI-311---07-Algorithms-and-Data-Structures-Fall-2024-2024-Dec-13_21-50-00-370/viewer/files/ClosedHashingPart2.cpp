#include <iostream>
using namespace std;

class HashTable {
private:
    int* table;
    int capacity;
    const int EMPTY_SLOT = -1; //extra added compared to part 1
    const int DELETED_SLOT = -2; //extra added compared to part 1

    int hash(int key) {
        return key % capacity;
    }

public:
    HashTable(int size) {
        capacity = size;
        table = new int[size];
        for(int i = 0; i < size; i++) {
            table[i] = EMPTY_SLOT; //extra added compared to part 1
        }
    }

    ~HashTable() {
        delete[] table;
    }

    // Quadratic probing insert
    bool insertQuadratic(int key) {
        int index = hash(key);
        int i = 0;
        int originalIndex = index;
        do {
            //extra added compared to part 1
            if (table[index] == EMPTY_SLOT || table[index] == DELETED_SLOT) {
                table[index] = key;
                return true;
            }
            i++;
            index = (originalIndex + i * i) % capacity;
        } while (index != originalIndex && i < capacity);
        return false;
    }

    // Quadratic probing delete
    bool deleteQuadratic(int key) {
        int index = hash(key);
        int i = 0;
        int originalIndex = index;
        do {
            if (table[index] == key) {
                //extra added compared to part 1
                table[index] = DELETED_SLOT;
                return true;
            } else if (table[index] == EMPTY_SLOT) {
                return false; // Key not found
            }
            i++;
            index = (originalIndex + i * i) % capacity;
        } while (index != originalIndex && i < capacity);
        return false;
    }

    void display() {
        for(int i = 0; i < capacity; i++) {
            if(table[i] != EMPTY_SLOT && table[i] != DELETED_SLOT)
                cout << i << " => " << table[i] << endl;
            else
                cout << i << " => [Empty]" << endl;
        }
    }
};

int main() {
    HashTable ht(10);

    // Demo with quadratic probing
    ht.insertQuadratic(5);
    ht.insertQuadratic(15);
    ht.insertQuadratic(25);
    ht.display();

    // Delete a key
    cout << "\nDeleting key 15" << endl;
    ht.deleteQuadratic(15);
    ht.display();

    // Delete a key
    cout << "\nDeleting key 25" << endl;
    ht.deleteQuadratic(25);
    ht.display();

    //cout << "\nInserting key 35" << endl;
    //ht.insertQuadratic(35);
    //ht.display();

    return 0;
}
