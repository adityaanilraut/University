#include<iostream>
#include<algorithm>
#include <string.h>
using namespace std;

// Recursive function with memoization (top-down DP)
int LCS(char X[], int m, char Y[], int n, int dp[][8]) {
    // If any of the strings is empty, return 0
    if (m == 0 || n == 0) {
        return 0;
    }
    
    // Check if the subproblem has already been solved
    if (dp[m][n] != -1) {
        return dp[m][n];
    }
    
    // If last characters match, add 1 to the result of the subproblem without the last characters
    if (X[m-1] == Y[n-1]) {
        dp[m][n] = 1 + LCS(X, m-1, Y, n-1, dp);
    } else {
        // If last characters do not match, take the maximum value from omitting the last character
        // in either string
        dp[m][n] = max(LCS(X, m-1, Y, n, dp), LCS(X, m, Y, n-1, dp));
    }
    
    return dp[m][n];
}

int main() {
    char X[] = "AGGTAB";
    char Y[] = "GXTXAYB";
    int m = strlen(X);
    int n = strlen(Y);
    
    // Memoization matrix, initialized to -1
    int dp[m+1][n+1];
    memset(dp, -1, sizeof(dp));
    
    cout << "Length of LCS is " << LCS(X, m, Y, n, dp) << endl;

    return 0;
}
