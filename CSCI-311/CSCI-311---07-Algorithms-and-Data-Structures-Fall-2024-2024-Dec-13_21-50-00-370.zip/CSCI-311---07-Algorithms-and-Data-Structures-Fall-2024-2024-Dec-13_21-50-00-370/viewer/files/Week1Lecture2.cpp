#include <iostream>
#include <string>
using namespace std;
const int ALPHABET_SIZE = 26;

class Trie {
private:
    class Node {
    public:
        Node* children[ALPHABET_SIZE];
        bool isEndOfWord;
        char data;

        Node(char c) 
        {
            data = c;
            isEndOfWord = false;
            for (int i = 0; i < ALPHABET_SIZE; i++) {
                children[i] = nullptr;
            }
        }
        
        Node() 
        {
            data = '\0';
            isEndOfWord = false;
            for (int i = 0; i < ALPHABET_SIZE; i++) {
                children[i] = nullptr;
            }
        }
    };

    Node* root;

    // Helper function for printing words in the Trie
    void printWords(Node* node, string prefix) {
        if (node == nullptr)
            return;

        if (node->data != '\0') {
            prefix += node->data;
        }

        if (node->isEndOfWord) {
            cout << prefix << " ";
        }

        for (int i = 0; i < ALPHABET_SIZE; i++) {
            printWords(node->children[i], prefix);
        }
    }

public:
    Trie() : root(new Node()) {}

    void insert(const string& word) {
        Node* temp = root;
        for (char c : word) {
            int index = c - 'a';
            if (temp->children[index]==nullptr) {
                temp->children[index] = new Node(c);
            }
            temp = temp->children[index];
        }
        temp->isEndOfWord = true;
    }

    void printWords() {
        printWords(root, "");
    }
};

int main() {
    Trie trie;

    // Insert some words into the Trie
    trie.insert("apple");
    trie.insert("appetite");
    trie.insert("banana");
    trie.insert("band");
    trie.insert("bat");
    trie.insert("batman");

    // Print the words
    cout << "Words stored in the Trie (ALPHABETICALLY ORDER): ";
    trie.printWords();
    cout << endl;

    return 0;
}
