#include <string>
#include <iostream>
using namespace std;

class BST {
private:
    class Node {
    public:
        string data;
        Node* left;
        Node* right;
        
Node(string val) {
    data = val;
    left = nullptr;
    right = nullptr;
}

    };
    
    Node* root;
    
    // Helper recursive functions
    Node* insert(Node* node, string val) {
        if(node==nullptr) return new Node(val);
        
        if(val < node->data)
            node->left = insert(node->left, val);
        else if(val > node->data)
            node->right = insert(node->right, val);
        
        return node;
    }
    
    void printInOrder(Node* node) {
        if(!node) return;
        printInOrder(node->left);
        cout << node->data << " ";
        printInOrder(node->right);
    }

public:
    BST(): root(nullptr) {}
    
    void insert(string val) {
        root = insert(root, val);
    }

    void printInOrder() {
        printInOrder(root);
    }
};

int main() {
    BST tree;

    // Insert some words into the BST
    tree.insert("apple");
    tree.insert("banana");
    tree.insert("cherry");
    tree.insert("date");
    tree.insert("fig");
    tree.insert("grape");
    
    
    cout << "Words in alphabetical order: ";
    tree.printInOrder();
    cout << endl;

    return 0;
}