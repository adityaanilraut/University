#include <iostream>
using namespace std;
long long fibonacci(int n) {
    if (n <= 2) return 1; // The first two Fibonacci numbers are 1

    long long window[2] = {1, 1}; // Window of the last two computed Fibonacci numbers
    int i=3;
    while(i<n)
    {
        long long nextFib = window[0] + window[1]; // Compute the next Fibonacci number
        window[0] = window[1]; // Move the window
        window[1] = nextFib;
        i=i+1;
    }

    return window[0] + window[1]; 
}

int main() {
    int n = 10; // Example: Finding the 10th Fibonacci number
    cout << "Fibonacci of " << n << " is " << fibonacci(n) << endl;
    return 0;
}
