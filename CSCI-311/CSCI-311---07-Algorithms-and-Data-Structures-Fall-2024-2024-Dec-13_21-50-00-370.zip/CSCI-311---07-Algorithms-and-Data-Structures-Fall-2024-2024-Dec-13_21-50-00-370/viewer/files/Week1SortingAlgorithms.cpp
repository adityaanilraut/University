#include <iostream>
using namespace std;
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}
void selectionSort(int arr[],int n)
{
    int i=-1; //i is keeping track of the start of the sorted array
    while(i<n-1)
    {
        printArray(arr,4);
        int bestMinIndexSoFar = i+1;
        int j=i+2;
        while(j<n)
        {
            if (arr[j]<arr[bestMinIndexSoFar])
            {
                bestMinIndexSoFar=j;
            }
            j=j+1;
        }
        //j = n 

        int temp = arr[bestMinIndexSoFar];
        arr[bestMinIndexSoFar]=arr[i+1];
        arr[i+1]=temp;
        i++;
        
    }
    //i=n-1


}

void insertionSort(int arr[],int n)
{
    int i=1;
    while(i<n)
    {
        printArray(arr,8);   
        int key=arr[i];
        int j=i-1;
        while(j>=0)
        {
            //printArray(arr,8);
            if (arr[j]>key)
            {
                arr[j+1]=arr[j];
                j=j-1;
            }
            else
            {
                break;
            }
        }   
        arr[j+1]=key;     
        //j=-1;
        i++;
    }
    //i=n

}
void bubbleSort(int arr[],int n)
{
    int i = n;
    while(i>0)
    {
        printArray(arr,4);
        bool isSwap=false;
        int j=0;
        /*
        Once the window has been placed, if it is within the valid bounds of j=0 to j=i-2
        then the swap is allowed. If the window is placed starting at j=i-1 then the swap is not
        allowed and the loop breaks. 
        */
        while(j<i-1)
        {
            if (arr[j]>arr[j+1])
            {
                isSwap=true;
                int temp = arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
            j++;
        }

        //j=i-1;  invalid bound of the window. 
        if (!isSwap)
            break;
        i=i-1;
}
//i=0

}


int main()
{

    int arr[]={64,32,12,0,-1,10,25,-4};
    int size = 8;
    //bubbleSort(arr,size);
    insertionSort(arr,size);
    printArray(arr,8);
}