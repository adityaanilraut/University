#include <iostream>
#include <algorithm> 
#include <cstdlib>   
using namespace std;

int partitionNew(int arr[], int low, int high) {
    // Randomly choose a pivot
    int randomIndex = rand() % ((high - low)+1);
    int pivot=arr[randomIndex+low];
    cout <<pivot<<endl;
    int j=low;
    int k=high+1;
    int i=low;
    while(j<k)
    {
        if (arr[j]==pivot)
        {
            j++;
        }
        else if (arr[j]<pivot)
        {
            swap(arr[j],arr[i]);
            i++;
            j++;
        }
        else
        {
            swap(arr[k-1],arr[j]);
            k--;
        }
    }
    return i;
}

/*
Worst case T(n) = T(n-1) + n 
escribes the worst-case scenario for QuickSort when a deterministic strategy is used, 
like always selecting the first element or the last element as the pivot, and the input list 
is already sorted (or reverse sorted). I
*/
void quickSortRandomPivot(int arr[], int low, int high) {
    if (low < high) {
        int pi = partitionNew(arr, low, high);

        quickSortRandomPivot(arr, low, pi - 1);
        quickSortRandomPivot(arr, pi + 1, high);
    }
}




// Helper function to find the median of five numbers
int medianOfFive(int arr[], int start) {
    sort(arr + start, arr + start + 5);
    return arr[start + 2];
}

/*
T(n) = T(n/5) + n 
*/
int medianOfMedians(int arr[], int low, int high) {
    int n = high - low + 1;
    int medians[(n + 4) / 5];
    int i;
    for (i = 0; i < n / 5; i++) {
        medians[i] = medianOfFive(arr, low + i * 5);
    }
    if (i * 5 < n) {
        sort(arr + low + i * 5, arr + high + 1);  
        //medians[i] = arr[low + i * 5 + ((high - (low + i * 5)) / 2)]; 
        medians[i] = arr[low + i * 5]; 
        i++;
    }
    if (i == 1)
        return medians[0];
    else
        return medianOfMedians(medians, 0, i - 1);
}

/*
T(n) = n 
*/

int partitionWithGivenPivotNew(int arr[], int low, int high, int pivot) {
    int j=low;
    int k=high+1;
    int i=low;
    while(j<k)
    {
        if (arr[j]==pivot)
        {
            j++;
        }
        else if (arr[j]<pivot)
        {
            swap(arr[j],arr[i]);
            i++;
            j++;
        }
        else
        {
            swap(arr[k-1],arr[j]);
            k--;
        }
    }
    return i;

}


/*
T(n) = n + T(3n/10)+T(7n/10)

*/
void quickSortMedianOfMedians(int arr[], int low, int high) {
    if (low < high) {
        int pivotValue = medianOfMedians(arr, low, high);
        int pi = partitionWithGivenPivotNew(arr, low, high, pivotValue);

        quickSortMedianOfMedians(arr, low, pi - 1);
        quickSortMedianOfMedians(arr, pi + 1, high);
    }
}


int main()
{
    int b[]={4,3,2,1,-4,-3,-2,-1};
    quickSortMedianOfMedians(b,0,7);
    for (int e:b)
    {
        cout << e << " ";
    }
}