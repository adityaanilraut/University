#include <iostream>
using namespace std;

/*
Top Down (Memoization) of Fib
*/
long long fibonacci(int n, long long memo[]) {
    if (n <= 2) return 1; // Base case: The first two numbers of the Fibonacci sequence are 1
    if (memo[n] != 0) return memo[n]; // If already computed, return the stored value
    memo[n] = fibonacci(n - 1, memo) + fibonacci(n - 2, memo); // Recursive calls with memoization
    return memo[n];
}

int main() {
    const int n = 10; // Example: Finding the 10th Fibonacci number
    long long memo[n+1] = {0}; // Initialize all elements to 0
    cout << "Fibonacci of " << n << " is " << fibonacci(n, memo) << endl;
    return 0;
}