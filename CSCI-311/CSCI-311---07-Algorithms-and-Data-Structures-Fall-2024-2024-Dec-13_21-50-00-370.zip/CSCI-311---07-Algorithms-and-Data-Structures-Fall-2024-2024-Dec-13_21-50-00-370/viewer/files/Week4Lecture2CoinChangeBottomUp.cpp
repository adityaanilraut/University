#include <iostream>
#include <algorithm>
using namespace std;
//T(A) = O(nA)
int coinChange(int coins[], int n, int amount) {
    int *dp = new int[amount + 1];
    for(int i = 0; i <= amount; i++) {
        dp[i] = amount + 1; // initializing with a large value
    }
    dp[0] = 0; // base case
    
    for(int i = 1; i <= amount; i++) {
        for(int j = 0; j < n; j++) {
            if(i - coins[j] >= 0) {
                dp[i] = min(dp[i], dp[i - coins[j]] + 1);
            }
        }
    }
    
    int result = dp[amount];
    delete[] dp;  // Clean up the dynamically allocated array
    
    return result > amount ? -1 : result;
}

int main() {
    int coins[] = {1, 2, 5};
    int n = sizeof(coins) / sizeof(coins[0]);
    int amount;
    cout << "Enter amount: ";
    cin >> amount;
    int result = coinChange(coins, n, amount);
    if(result != -1)
        cout << "Minimum coins required: " << result << endl;
    else
        cout << "Amount cannot be formed with given coins." << endl;
    return 0;
}
