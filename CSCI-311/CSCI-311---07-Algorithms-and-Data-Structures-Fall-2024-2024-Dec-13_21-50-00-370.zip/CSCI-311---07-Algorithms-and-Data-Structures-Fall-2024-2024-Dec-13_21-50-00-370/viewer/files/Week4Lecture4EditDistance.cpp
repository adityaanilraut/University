#include <iostream>
#include <algorithm> 

using namespace std;

int editDistance(char str1[], char str2[], int len1, int len2) {
    int dp[len1 + 1][len2 + 1];

    for (int i = 0; i <= len1; i++) {
        for (int j = 0; j <= len2; j++) {
            if (i == 0) {
                dp[i][j] = j; 
            } else if (j == 0) {
                dp[i][j] = i; 
            } else if (str1[i - 1] == str2[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1]; // No operation needed. In lecture I used diff and here diff=0
            } else {
                dp[i][j] = 1 + min({dp[i][j - 1],    // Insert
                                     dp[i - 1][j],    // Remove
                                     dp[i - 1][j - 1] // Replace. In lecture I used diff and here diff=1
                                    });
            }
        }
    }
    return dp[len1][len2];
}

int main() {
    char str1[] = "exponential";
    char str2[] = "polynomial";
    int len1 = sizeof(str1) - 1; // Subtract 1 to avoid counting the null terminator
    int len2 = sizeof(str2) - 1; // Subtract 1 to avoid counting the null terminator

    cout << "Edit distance is " << editDistance(str1, str2, len1, len2) << endl;
    return 0;
}
