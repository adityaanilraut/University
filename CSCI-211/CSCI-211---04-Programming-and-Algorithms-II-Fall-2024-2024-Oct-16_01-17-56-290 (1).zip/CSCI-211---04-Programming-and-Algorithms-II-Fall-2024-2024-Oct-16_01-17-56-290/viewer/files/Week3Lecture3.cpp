#include <iostream>
using namespace std;
#include "video.h"

/*
What is the purpose of the code in the main function?
The purpose of the code in the main function is to create and manipulate objects of the Video class. It creates objects using both stack-based and heap-based memory allocation, and demonstrates different ways of creating and manipulating arrays of Video objects.

What does the line Video video1=Video ("movie1","location1","c1",1.0,1); do?
This line creates a Video object named "video1" using the constructor and initializes its member variables with the given values "movie1", "location1", "c1", 1.0, and 1.

What is the difference between the stack and heap memory allocation in C++?
Stack memory allocation is temporary and stores data in a last-in-first-out (LIFO) order. It is automatically managed by the compiler and deallocated when the program exits the scope in which the memory was allocated. Heap memory allocation is permanent and requires manual management of memory allocation and deallocation. Objects created on the heap remain in memory until explicitly deleted.

What is the purpose of the line Video arr[2]={video1,video2};?
This line creates an array of Video objects on the stack and initializes it with the objects "video1" and "video2".

How would you modify the name of a video stored in the array "arr1"?
To modify the name of a video stored in the array "arr1", you would use the setName() method on the desired element of the array, for example: arr1[1]->setName("newname");.

What is the purpose of the line Video* arr2[2]={new Video("movie5","location5","c5",5.0,5),new Video("movie6","location6","c6",6.0,6)};?
This line creates an array of pointers to Video objects on the stack and initializes it with two Video objects created on the heap using the "new" operator.

What is the difference between the lines Video arr[2]={video1,video2}; and Video* arr2[2]={new Video("movie5","location5","c5",5.0,5),new Video("movie6","location6","c6",6.0,6)};?
The difference between these two lines is the memory allocation of the objects being stored in the arrays. The first line, Video arr[2]={video1,video2};, creates an array of Video objects on the stack and initializes it with stack-allocated Video objects. The second line, Video* arr2[2]={new Video("movie5","location5","c5",5.0,5),new Video("movie6","location6","c6",6.0,6)};, creates an array of pointers to Video objects on the stack and initializes it with heap-allocated Video objects.

In the given code, which objects are stack-allocated and which objects are heap-allocated?
The objects video1, video2, arr, and arr1 are stack-allocated, while the objects video3, video4, arr2, arr3, and arr4 are heap-allocated.

Why are video3 and video4 heap-allocated?
video3 and video4 are heap-allocated because they are dynamically allocated using the new operator, which reserves memory from the heap. This allows for dynamic allocation of objects that persist beyond the scope of the function.

What is the difference between arr and arr1?
arr is an array of Video objects, while arr1 is an array of pointers to Video objects. arr is stack-allocated, while arr1 is heap-allocated because the objects being pointed to are heap-allocated.

Why is arr2 heap-allocated?
arr2 is heap-allocated because it is an array of pointers to dynamically allocated Video objects. The memory for these objects is reserved from the heap using the new operator, so the array of pointers must also be heap-allocated.

What is the difference between arr3 and arr4?
arr3 is a dynamically allocated array of Video objects, while arr4 is a dynamically allocated array of pointers to Video objects. In both cases, the memory is reserved from the heap using the new operator. The main difference is that arr3 holds actual Video objects, while arr4 holds pointers to dynamically allocated Video objects.

*/
int main()
{
    Video video1=Video ("movie1","location1","c1",1.0,1);
    Video video2= Video ("movie2","location2","c2",2.0,2);
    video1.print();
    video2.print();

    Video* video3=new Video("movie3","location3","c3",3.0,3);
    Video* video4=new Video("movie4","location4","c4",4.0,4);
    video3->print();
    video4->print();

    Video arr[2]={video1,video2};
    arr[0].setName("video1newname");
    video1.print();
    arr[0].print();

    Video* arr1[2]={&video1,&video2};
    arr1[1]->setName("video2newname");
    video2.print();
    arr1[1]->print();

    Video* arr2[2]={new Video("movie5","location5","c5",5.0,5),new Video("movie6","location6","c6",6.0,6)};
    arr2[0]->setName("newname5");
    arr2[0]->print();

    Video* arr3=new Video[2];
    arr3[0]=Video ("movie7","location7","c7",7.0,7);
    arr3[1]=Video ("movie8","location8","c8",8.0,8);
    arr3[0].setName("newname7");
    arr3[0].print();

    Video** arr4=new Video*[2];
    arr4[0]=new Video ("movie9","location9","c9",9.0,9);
    arr4[1]=new Video ("movie10","location10","c10",10.0,10);
    arr4[0]->setName("newname9");
    arr4[0]->print();

}