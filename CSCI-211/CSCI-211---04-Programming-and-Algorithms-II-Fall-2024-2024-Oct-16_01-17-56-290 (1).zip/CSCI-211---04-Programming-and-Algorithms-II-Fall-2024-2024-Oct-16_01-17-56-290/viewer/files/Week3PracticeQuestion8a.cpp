/*
Write a program to find the sum and average of n numbers, 
where n is entered by the user. 
The numbers should be stored in an array, and the sum and average 
should be calculated using pointers.
*/

#include <iostream>

int main()
{
    int n, sum = 0;
    float average;

    std::cout << "Enter the number of elements: ";
    std::cin >> n;

    int *numbers = new int[n];

    std::cout << "Enter the numbers: ";
    for (int i = 0; i < n; i++)
    {
        std::cin >> *(numbers + i);
        sum += *(numbers + i);
    }

    average = (float)sum / n;

    std::cout << "Sum: " << sum << std::endl;
    std::cout << "Average: " << average << std::endl;

    delete[] numbers;

    return 0;
}
