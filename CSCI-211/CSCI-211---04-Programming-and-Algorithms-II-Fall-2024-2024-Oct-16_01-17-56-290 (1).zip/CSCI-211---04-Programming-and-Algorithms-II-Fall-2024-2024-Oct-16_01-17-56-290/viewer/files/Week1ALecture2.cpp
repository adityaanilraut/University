#include <iostream>
using namespace std;

/*
What does the function binarysearch do?
Answer: The function performs a binary search on an integer array, using the input size of the array and the search item, to find the index of the search item in the array. If the search item is not found in the array, the function returns -1.

What is the purpose of the "leftIndex" and "rightIndex" variables?
Answer: The "leftIndex" variable keeps track of the starting index of the portion of the array currently being searched, while the "rightIndex" variable keeps track of the ending index of the portion of the array currently being searched.

What happens if the search item is found in the array?
Answer: If the search item is found in the array, the function returns the index of the search item in the array.

What is the purpose of the "middleIndex" variable?
Answer: The "middleIndex" variable is used to calculate the middle index of the portion of the array currently being searched. This is done by taking the average of the "leftIndex" and "rightIndex" variables.

What happens if the search item is not found in the array?
Answer: If the search item is not found in the array, the function returns -1, indicating that the search item is not present in the array.

What is the purpose of the "while" loop in the function?
Answer: The "while" loop is used to repeatedly search the portion of the array between "leftIndex" and "rightIndex" until either the search item is found or all elements have been searched and the search item is not found.

*/ 

 /*
 PreCondition: The arr must be sorted for binary search to work correctly!

 */


int binarysearch2Incorrect(int arr[], int size, int searchItem)
{
    int leftIndex=0;
    int rightIndex=size-1;
    
        
        while(leftIndex<=rightIndex)
        {
            //elements still remaining to be looked at
            int middleIndex=(leftIndex+rightIndex)/2;
            if (arr[middleIndex]==searchItem)
            {
                return middleIndex;
            }
            else if (arr[middleIndex]>searchItem)
            {
                rightIndex=middleIndex-1;
            }
            else
            {
                leftIndex=middleIndex+1;
            }
        }
    return -1;

}


int binarysearch(int arr[], int size, int searchItem)
{
    int leftIndex=0;
    int rightIndex=size-1;
    
        
        while(leftIndex<=rightIndex)
        {
            cout <<"The loop just ran!" <<endl;
        //elements still remaining to be looked at
            int middleIndex=(leftIndex+rightIndex)/2;
            if (arr[middleIndex]==searchItem)
            {
                return middleIndex;
            }
            else if (arr[middleIndex]>searchItem)
            {
                rightIndex=middleIndex-1;
            }
            else
            {
                leftIndex=middleIndex+1;
            }
        }
    return -1;

}

// Driver code
int main(void)
{
    int arr[] = { 10, 20, 30, 40, 50 };
    int x = 20;
    // Function call
    int result = binarysearch2Incorrect(arr, 5, x);
    if (result == -1)
        cout << "Element is not present in array";
    else
        cout << "Element is present at index " << result <<endl;
    return 0;
}