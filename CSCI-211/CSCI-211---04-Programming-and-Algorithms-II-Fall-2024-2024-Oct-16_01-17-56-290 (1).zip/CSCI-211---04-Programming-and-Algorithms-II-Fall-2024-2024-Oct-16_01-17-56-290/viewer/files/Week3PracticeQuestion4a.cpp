/*
Write a simple fraction class that represents the idea of a fraction. 
A fraction has a numerator and a denominator. Your fraction class must 
be able to add, subtract, divide and multiply*/


#include <iostream>

class Fraction
{
    int *numerator;
    int *denominator;

public:
    Fraction(int num, int den)
    {
        numerator = new int;
        denominator = new int;
        *numerator = num;
        *denominator = den;
    }

    Fraction add(Fraction const &f2)
    {
        int newNum = *numerator * *f2.denominator + *f2.numerator * *denominator;
        int newDen = *denominator * *f2.denominator;
        return Fraction(newNum, newDen);
    }

    Fraction subtract(Fraction const &f2)
    {
        int newNum = *numerator * *f2.denominator - *f2.numerator * *denominator;
        int newDen = *denominator * *f2.denominator;
        return Fraction(newNum, newDen);
    }

    Fraction multiply(Fraction const &f2)
    {
        int newNum = *numerator * *f2.numerator;
        int newDen = *denominator * *f2.denominator;
        return Fraction(newNum, newDen);
    }

    Fraction divide(Fraction const &f2)
    {
        int newNum = *numerator * *f2.denominator;
        int newDen = *denominator * *f2.numerator;
        return Fraction(newNum, newDen);
    }

    void display()
    {
        std::cout << *numerator << "/" << *denominator << std::endl;
    }
};

int main()
{
    Fraction f1(1, 2);
    Fraction f2(1, 3);
    Fraction f3 = f1.add(f2);
    f3.display();

    Fraction f4 = f1.subtract(f2);
    f4.display();

    Fraction f5 = f1.multiply(f2);
    f5.display();

    Fraction f6 = f1.divide(f2);
    f6.display();

    return 0;
}
