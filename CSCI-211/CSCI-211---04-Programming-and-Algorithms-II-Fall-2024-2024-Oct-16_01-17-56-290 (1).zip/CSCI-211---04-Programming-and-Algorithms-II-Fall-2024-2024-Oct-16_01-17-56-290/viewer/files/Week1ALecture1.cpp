#include <iostream>
using namespace std;
 /*
 What is the purpose of the function search()?
The purpose of the function search() is to find the index of an element x in an array arr.

What does the line "int n = sizeof(arr) / sizeof(arr[0])" do?
The line "int n = sizeof(arr) / sizeof(arr[0])" calculates the size of the array arr by dividing the total size of the array by the size of each element in the array. This helps to determine the number of elements present in the array.

How does the function search() determine if the element x is present in the array or not?
The function search() determines if the element x is present in the array by iterating over the elements of the array using a while loop and checking if each element is equal to x. If the element is found, the function returns its index. If the element is not found, the function returns -1.

Can you explain the while loop in the function search()?
The while loop in the function search() starts with the index value of 0 and continues to run until the index value is less than the size of the array. At each iteration, the loop checks if the current element is equal to x. If it is, the function returns the index. If not, the index is incremented by 1, and the loop continues until the end of the array is reached.

What would happen if the element x is not present in the array?
If the element x is not present in the array, the function search() would return -1. This value is used to indicate that the element was not found in the array.
 */
int search(int arr[], int n, int x)
{
    int index = 0 ;
    while (index<n)
    {
        if (arr[index]==x)
            return index;
        index=index+1;
    }
    return -1;
}
 
// Driver code
int main(void)
{
    int arr[] = { 2, 3, 4, 10, 40 };
    int x = 100;
    int n = sizeof(arr) / sizeof(arr[0]);
   
    // Function call
    int result = search(arr, n, x);
    if (result == -1)
        cout << "Element is not present in array";
    else
        cout << "Element is present at index " << result;
    return 0;
}