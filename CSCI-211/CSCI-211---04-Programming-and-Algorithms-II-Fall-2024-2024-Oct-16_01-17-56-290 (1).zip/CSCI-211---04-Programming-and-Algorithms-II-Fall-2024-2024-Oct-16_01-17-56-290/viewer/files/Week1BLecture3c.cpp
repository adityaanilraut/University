#include <iostream>
using namespace std;
/*
What is the purpose of the code?
Answer: The purpose of the code is to find the maximum value in an integer array.

How does the code determine the maximum value in the array?
Answer: The code uses a for loop to iterate through the elements in the array, and a conditional statement to compare the current element with the current maximum value. If the current element is greater than the current maximum value, it updates the maximum value.

How does the code get the size of the array?
Answer: The code calculates the size of the array by dividing the size of the entire array by the size of a single element in the array, using the following expression: sizeof(arr)/sizeof(arr[0]).

What does the following line of code do? int *ptr=arr;
Answer: The line of code declares a pointer variable "ptr" and initializes it with the starting address of the array "arr". This allows the code to access the elements of the array using the pointer.

How does the code access the elements of the array using the pointer?
Answer: The code accesses the elements of the array using the pointer by using the pointer arithmetic, i.e., adding an integer to the pointer to access the next element in the array. For example, *(arr+i) accesses the i-th element in the array.

*/
int main() {
  int arr[] = {100, 2, 3, 40, 51};
  int n = sizeof(arr)/sizeof(arr[0]);
  int *ptr=arr;
  int max = *ptr;
  for (int i=1;i<n;i++)
  {
    if (*(arr+i)>max)
    {
      max=*(arr+i);
    }
  }
  
  cout << "The maximum value is: " << max << endl;
  return 0;
}