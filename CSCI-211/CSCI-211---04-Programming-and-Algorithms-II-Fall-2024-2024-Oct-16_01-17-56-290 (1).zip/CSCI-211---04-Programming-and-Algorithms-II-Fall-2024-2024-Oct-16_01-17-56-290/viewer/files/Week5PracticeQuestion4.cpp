/*

Question)

Write a function that takes two LinkedListStack 
objects as arguments and returns a new 
LinkedListStack object with the elements of both stacks 
merged, alternating between the two stacks. 
For example, if the first stack contains 1, 2, and 3, and 
the second stack contains 4, 5, and 6, the merged 
stack should contain 1, 4, 2, 5, 3, 6.
*/


LinkedListStack merge_stacks(LinkedListStack stack1, LinkedListStack stack2) {
LinkedListStack merged_stack;
while (!stack1.is_empty() || !stack2.is_empty()) {
if (!stack1.is_empty()) {
merged_stack.push(stack1.top());
stack1.pop();
}
if (!stack2.is_empty()) {
merged_stack.push(stack2.top());
stack2.pop();
}
}
return merged_stack;
}