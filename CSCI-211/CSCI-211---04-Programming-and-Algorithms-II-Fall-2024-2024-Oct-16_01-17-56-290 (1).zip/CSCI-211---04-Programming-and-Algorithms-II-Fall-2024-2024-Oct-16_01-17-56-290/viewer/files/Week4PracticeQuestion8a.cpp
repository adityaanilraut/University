/*
Suppose you have a C++ class called LinkedList 
that represents a singly linked list of integers, 
with a head pointer pointing to the first node 
in the list. Write a destructor for this class 
that properly deallocates all the nodes in the list.
*/


class LinkedList {
private:
class Node {
public:
  int data;
  Node* next;
  Node(int d) {
    data = d;
    next = nullptr;
  }
  ~Node() { }
};
  Node* head;
  
public:
  LinkedList() {
    head = nullptr;
  }
  ~LinkedList() {
    Node* curr = head;
    while (curr != nullptr) {
      Node* next = curr->next;
      delete curr;
      curr = next;
    }
  }
};
