#include <iostream>
using namespace std;

int factorial(unsigned n)
{
    if (n==0) { // Base case: if n is 0, return 1
        return 1;
    }
    return n*factorial(n-1); // Recursive call: n times factorial of n-1
}

int sum (int*a, int length, int index)
{
    if (index==length-1) // Base case: if index is the last element, return its value
    {
        return a[index];
    }
    // Recursive call: current element value plus sum of the rest
    return a[index]+sum(a,length,index+1);
}

int dotProduct (int *v1, int *v2, int length, int index)
{
    if (index==length-1) // Base case: if index is the last element, return the product of the corresponding elements
    {
     return v1[index]*v2[index];
    }
    else
    {
        // Recursive call: get the dot product of the rest of the vectors
        int partialDotProduct = dotProduct (v1, v2, length, index+1);
        // Return the product of the corresponding elements plus the partial dot product
        return v1[index]*v2[index]+partialDotProduct;
    }
}

int findMax(int *p, int index, int length)
{

    if (index==length-1) // Base case: if index is the last element, return its value
    {
     return p[index];
    }
    {
        // Recursive call: find the maximum value in the rest of the array
        int maxSoFar = findMax(p,index+1,length);
        if (p[index]>maxSoFar) // If current element is greater than the maximum found so far, return it
            return p[index];
        else    
            return maxSoFar; // Else, return the maximum found so far

    }

}

void reverse (int*p, int index, int length)
{
    if (index==length-1) // Base case: if index is the last element, return (do nothing)
    {
        return;
    }
    reverse(p,index+1,length); // Recursive call: reverse the rest of the array
    int counter=index+1;
    int valueAtFirstIndex=p[index]; // Store the value at the current index
    while(counter<length) // Shift all elements to the left by one position
    {
        p[counter-1]=p[counter];
        counter=counter+1;
    }
    p[counter-1]=valueAtFirstIndex; // Place the value at the current index at the end

}

int main()
{

    int output=factorial (5);
    cout <<"The factorial of 5 is " <<output <<endl; 

    int a[]={9,8,7,1,2,23};
    output=sum(a,6,0);
    cout <<"The sum of the array is " <<output <<endl; 

    int v1[]={-2,2,5,4,-1};
    int v2[]={6,7,8,9,10};
    output = dotProduct(v1,v2,5,0);
    cout <<"The dot product is " <<output <<endl; 

    int max=findMax(v1,0,5);
    cout <<"the maximum in the array is " << max << endl;


    for(auto value:v1)
    {
        cout <<value<<endl;
    }
    cout <<"reverse is about to get called" <<endl;
    reverse(v1,0,5);
    for(auto value:v1)
    {
        cout <<value<<endl;
    }

}