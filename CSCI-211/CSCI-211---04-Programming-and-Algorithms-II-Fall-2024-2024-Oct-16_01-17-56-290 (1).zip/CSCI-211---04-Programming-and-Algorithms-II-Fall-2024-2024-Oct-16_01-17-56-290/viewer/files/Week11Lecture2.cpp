#include <iostream>

class Base {
public:
    virtual void foo() {
        std::cout << "Base::foo (overridden)" << std::endl;
    }

    void bar() {
        std::cout << "Base::bar (hidden)" << std::endl;
    }
};

class Derived : public Base {
public:
    void foo() override {
        std::cout << "Derived::foo (overriding)" << std::endl;
    }

    void bar() {
        std::cout << "Derived::bar (hiding)" << std::endl;
    }
};

int main() {
    Base *b = new Derived();

    b->foo(); // Output: Derived::foo (overriding)
    b->bar(); // Output: Base::bar (hidden)

    delete b;
    return 0;
}
