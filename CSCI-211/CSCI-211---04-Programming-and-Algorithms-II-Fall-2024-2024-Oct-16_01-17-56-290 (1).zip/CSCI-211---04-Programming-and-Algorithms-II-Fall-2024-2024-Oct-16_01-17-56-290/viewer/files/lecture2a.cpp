#include <iostream>
using namespace std;
void stack_func() {
    int x = 10;
    x++;
}

void heap_func() {
    int *p = new int;
    *p = 10;
    (*p)++;
    delete p;
}

int main() {    
        stack_func();
        heap_func();
}