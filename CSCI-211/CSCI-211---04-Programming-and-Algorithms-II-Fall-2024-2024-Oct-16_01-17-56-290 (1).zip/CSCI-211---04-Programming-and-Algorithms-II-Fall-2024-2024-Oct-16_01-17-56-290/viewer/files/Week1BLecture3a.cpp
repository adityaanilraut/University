#include <iostream>
using namespace std;
/*
What does the main function in the code do?
The main function in the code is used to demonstrate the use of various data types in C++, including characters, integers, and doubles. It uses the printf function and cout statement to print the value, address, and size of each variable.

What is the purpose of the printf function in the code?
The printf function is used to print the value, address, and size of each variable. It is used to display the value of the variable, which is specified using the format specifier (%c, %i, or %f), and the address of the variable, which is specified using the format specifier %p.

What is the purpose of the sizeof operator in the code?
The sizeof operator is used to determine the size in bytes of a data type. In the code, it is used to determine the size of each variable and display the result using the cout statement.

How does the code determine the address of each variable?
The address of each variable is determined by using the address-of operator (&). This operator returns the memory address of the variable, which can then be used to access the value stored in that memory location. In the code, the address of each variable is displayed using the printf function and the format specifier %p.

How does the code determine the value of each variable?
The value of each variable is determined by simply using the variable name in the printf function. The value is then displayed using the format specifier (%c, %i, or %f) in the printf function, depending on the data type of the variable.

*/
int main()
{

    char x2='a';
    printf("The value of x2 is %c\n",x2);
    printf("The address of x2 is %p\n",&x2);
    cout << "The size of x2 is " << sizeof(x2) <<endl;

    int x = 1;
    printf("The value of x is %i\n",x);
    printf("The address of x is %p\n",&x);
    cout << "The size of x is " << sizeof(x) <<endl;
    

    double x1 = 1;
    printf("The value of x1 is %f\n",x1);
    printf("The address of x1 is %p\n",&x1);
    cout << "The size of x is " << sizeof(x1) <<endl;

    float x3 = 1;
    printf("The value of x3 is %f\n",x3);
    printf("The address of x3 is %p\n",&x3);
    cout << "The size of x3 is " << sizeof(x3) <<endl;


}