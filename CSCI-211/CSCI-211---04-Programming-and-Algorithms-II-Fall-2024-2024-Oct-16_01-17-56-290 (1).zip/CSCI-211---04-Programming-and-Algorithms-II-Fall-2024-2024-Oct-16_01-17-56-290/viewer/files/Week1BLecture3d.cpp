#include <iostream>
using namespace std;
/*
Q1. What does the "reverse" function do in the given code?

A1. The "reverse" function takes an integer array and its size as input and it reverses the elements of the array.

Q2. How does the "reverse" function work in the given code?

A2. The "reverse" function works by using two pointers, "left" and "right". "left" points to the first element of the array, and "right" points to the last element of the array. In each iteration of the while loop, the values of the two elements pointed to by "left" and "right" are swapped, and then "left" and "right" are incremented and decremented respectively. The loop continues until "left" becomes greater than or equal to "right".

Q3. What is the output of the code?

A3. The output of the code is:
Original array: 1 2 3 4 5
Reversed array: 5 4 3 2 1

Q4. How does the main function use the "reverse" function?

A4. The main function first initializes an array of integers, then it calls the "reverse" function and passes the array and its size as arguments. The main function then prints the original array and the reversed array.
*/
void reverse(int *arr, int n) {
  int *left = arr;
  int *right = arr + (n-1);

while(left<right)
{
    int temp=*left;
  *left=*right;
  *right=temp;
  left++;
  right--;
}


}

int main() {
  int arr[] = {1, 2, 3, 4, 5};
  int n = sizeof(arr)/sizeof(arr[0]);
  cout << "Original array: ";
  for (int i = 0; i < n; i++) {
    cout << arr[i] << " ";
  }
  cout << endl;
  reverse(arr, n);
  cout << "Reversed array: ";
  for (int i = 0; i < n; i++) {
    cout << arr[i] << " ";
  }
  cout << endl;
  return 0;
}