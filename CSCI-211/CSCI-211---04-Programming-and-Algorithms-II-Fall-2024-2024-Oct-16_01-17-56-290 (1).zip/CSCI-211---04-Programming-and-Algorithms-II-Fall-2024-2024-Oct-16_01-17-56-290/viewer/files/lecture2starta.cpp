#include <iostream>
using namespace std;
/*

What is the purpose of the following line of code?
int *ptr[3];
Solution: The line of code creates an array of 3 integer pointers, named "ptr".

What values do the elements of the "ptr" array hold after the following code is executed?
ptr[0] = &x;
ptr[1] = &y;
ptr[2] = &z;
Solution: After the execution of the code, the elements of the "ptr" array hold the addresses of variables "x", "y", and "z", respectively.

What is the output of the following line of code?
cout << x << endl;
Solution: The output of the line of code is "50".

What does the following line of code do?
*ptr[0] = *ptr[1] + *ptr[2];
Solution: The line of code dereferences the value stored in the first element of the "ptr" array, and assigns the sum of the values stored in the second and third elements of the "ptr" array. As a result, the value stored in the memory location pointed to by "ptr[0]" is updated.

What happens if the line of code "cout << x << endl;" is changed to "cout << y << endl;"?
Solution: If the line of code is changed, the output would be "20" instead of "50".

What is the purpose of the line "int *ptr[3];"?
Solution: The line of code creates an array of 3 integer pointers, named "ptr".

What is the difference between "ptr" and "&x"?
Solution: "ptr" is an array of 3 integer pointers, while "&x" is the address of the integer variable "x".

What happens if the line of code "ptr[0] = &x;" is changed to "ptr[0] = x;"?
Solution: If the line of code is changed, it will result in a compiler error, as the expression on the right-hand side is an integer value and not an address. The value stored in "ptr[0]" must be an address of an integer variable, not an integer value.

*/


int main() {
    int x = 10, y = 20, z = 30;
    int *ptr[3];
    ptr[0] = &x;
    ptr[1] = &y;
    ptr[2] = &z;
    *ptr[0] = *ptr[1] + *ptr[2];
    cout << x << endl;
    return 0;
}