/*
Given a list of tasks with priorities, implement a priority queue 
to schedule them.
*/

#include <iostream>
#include <queue>

using namespace std;

class Task {
public:
    // Constructor that takes the priority and name of the task as arguments
    Task(int p, string n) : priority(p), name(n) {}
    
    // Overload the less than operator to compare priorities of two tasks
    bool operator<(const Task& other) const {
        return priority < other.priority;
    }
    
    // Getter method to return the name of the task
    string getName() const {
        return name;
    }
    
private:
    int priority;
    string name;
};

int main() {
    // Create a priority queue of tasks
    priority_queue<Task> pq;
    
    // Add some tasks to the queue
    pq.push(Task(2, "Task 1"));
    pq.push(Task(1, "Task 2"));
    pq.push(Task(3, "Task 3"));
    
    // Process tasks in priority order
    while (!pq.empty()) {
        // Get the highest priority task
        Task t = pq.top();
        
        // Print the name of the task
        cout << t.getName() << endl;
        
        // Remove the task from the queue
        pq.pop();
    }
    
    return 0;
}
