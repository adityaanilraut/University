/*
Write a C++ function that takes an array of integers and its 
length as input, and returns the sum of all elements in the 
array that are divisible by 3.
*/

int sumDivisibleByThree(int arr[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        if (arr[i] % 3 == 0) {
            sum += arr[i];
        }
    }
    return sum;
}
