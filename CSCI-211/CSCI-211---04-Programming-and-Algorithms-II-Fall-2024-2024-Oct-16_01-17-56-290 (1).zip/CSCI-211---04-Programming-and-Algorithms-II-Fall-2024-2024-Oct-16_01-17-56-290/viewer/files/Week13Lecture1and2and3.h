#ifndef __BINARYTREE_H
#define __BINARYTREE_H
#include <queue>
#include <iostream>
#include <limits>
using namespace std;
template<class T>
class BinaryTree
{

    private: 
    class Node
    {
        private:
        T data;
        Node* left;
        Node* right;
        friend class BinaryTree;

        public:
        Node(T data, Node* l, Node* r)
        {
            this->data=data;
            this->left=l;
            this->right=r;
        }

        ~Node()
        {
            //delete left;
            //delete right;
        }
        void addData(T data)
        {
            queue<Node*> q;
            q.push(this);
            while(!q.empty())
            {
                Node* n=q.front();
                q.pop();
                if (n->left==nullptr)
                {
                    n->left=new Node(data,nullptr,nullptr);
                    break;
                }
                else if (n->right==nullptr)
                {
                    n->right=new Node(data,nullptr,nullptr);
                    break;
                }
                q.push(n->left);
                q.push(n->right); 
            }
        }
        
    };

    public:
    Node* root;
    BinaryTree()
    {
        root=nullptr;
    }
    void addData(T data)
    {
        if (root==nullptr)
            root=new Node(data,nullptr,nullptr);
        else
        {
            root->addData(data);
        }
    }

    void __printPreOrder(Node* n, int depth)
    {
        if (n==nullptr)
            return;
        int index=0;
        string ret="";
        while(index<depth)
        {
            ret=ret+" ";
            index++;
        }
        cout << ret<<n->data <<endl;
        __printPreOrder(n->left,depth+1);
        __printPreOrder(n->right,depth+1);
    }
    void printPreOrder()
    {
        if (root==nullptr)
            return;
        else
        __printPreOrder(root,0);
    }

    void printLevelOrder()
    {
        if (root==nullptr)
            return;
        else
        {
            queue<Node*> q;
            q.push(this->root);
            while(q.size()!=0)
            {
                
                Node* toPrint=q.front();
                cout << toPrint->data <<endl;
                q.pop();
                if(toPrint->left!=nullptr)
                    q.push(toPrint->left);
                if(toPrint->right!=nullptr)    
                    q.push(toPrint->right);
            }
        }
    }

Node* __makeMirror(Node* n)
{
    if (n==nullptr)
        return nullptr;
    else
    {
        Node* oldRight=n->right;
        n->right=__makeMirror(n->left);
        n->left=__makeMirror(oldRight);
        return n;
    }
}
void makeMirror()
{
    if (root==nullptr)
        return;
    else
        __makeMirror(root);
}

int __getSum(Node* n)
{
    if (n==nullptr)
        return 0;
    else 
        return n->data+__getSum(n->left)+__getSum(n->right);
}
int getSum()
{
    if (root==nullptr)
        throw ("Empty binary tree");
    else
        return __getSum(root);
}

bool __isBST(Node* n, int min,int max)
{
    if (n==nullptr)
        return true;
    else
    {
        if (n->data>min && n->data<max)
        {
            bool isLeftBST=__isBST(n->left,min,n->data);
            bool isRightBST=__isBST(n->right,n->data,max);
            return (isLeftBST && isRightBST);
        }
        return false;
        
    }
}
bool isBST()
{
    if (root==nullptr)
        return true;
    else
        return __isBST(root,INT32_MIN,INT32_MAX);
}


T __getMaxR(Node* r)
{
    if (r->right==nullptr)
        return r->data;
    else
        return __getMaxR(r->right);
}
T getMaxR()
{
    if (root==nullptr)
        throw "Binary tree is empty";
    else 
    return __getMaxR(root);

}

T getMax()
{
    if (root==nullptr)
        throw "Binary tree is empty";
    Node* current=root;
    Node* previous=nullptr;
    while(current!=nullptr)
    {
        previous=current;
        current=current->right;
    }
    return previous->data;

}
Node* __addBST(Node* r, T data)
{
    if (r==nullptr)
    {
        return new Node(data,nullptr,nullptr);
    }
    if (r->data<data)
    {
        r->right=__addBST(r->right,data);
        return r;
    }
    else
    {
        r->left=__addBST(r->left,data);
        return r;
    }
}
void addBST(T data)
{
    if (root==nullptr)
        root=new Node(data,nullptr,nullptr);
    else
        __addBST(root,data);
}

void __range(T low, T high, queue<T> *range, Node* r)
{
    if (r==nullptr)
        return;
    else
    {
        if (r->data>low)
        {
             __range(low, high, range,r->left);
        }
        if (r->data>=low && r->data<=high)
        {
            range->push(r->data);
        }
        if (r->data<high)
        {
             __range(low, high, range,r->right);
        }
    }
}
queue<T>* range(T low, T high)
{
    if (root==nullptr)
        throw "Cannot call range on empty tree";
    else
    {
        queue<T> *range=new queue<T>();
        __range(low, high,range,root);
        return range;
    }
}
int __getSize(Node* r)
{
    if (r==nullptr)
        return 0;
    else 
    {
        return 1+__getSize(r->left)+__getSize(r->right);
    }
}
int getSize()
{
     return __getSize(root);
}

int __getRank(Node* root, T data)
{
    if (root==nullptr)
        return 0;
    else
    {
        if (root->data<data)
        {
            return __getSize(root->left)+1+__getRank(root->right,data);
        }
        else if (root->data>data)
        {
            return __getRank(root->left,data);
        }
        else 
        {
            return __getSize(root->left);
        }
    }
}
int getRank(T data)
{
    if (root==nullptr)
        return 0;
    else 
        return __getRank(root, data);
}

Node* __delete(Node* r, T deleteItem)
{
    if (r==nullptr)
        return nullptr;
    else if (r->data>deleteItem)
    {
        r->left=__delete(r->left,deleteItem);
        return r;
    }
    else if (r->data<deleteItem)
    {
        r->right=__delete(r->right,deleteItem);
        return r;
    }
    else 
    {
        if (r->left==nullptr)
        {
            return r->right;
        }
        if (r->right==nullptr)
        {
            return r->left;
        }
        Node* min = __getMin(r->right);
        min->right =__deleteMin(r->right);
        min->left=r->left;
        
        return min;
    }
}
void deleteN(T deleteItem)
{
    if (root==nullptr)
        throw "Cannot delete on an empty binary tree";
    else 
        root=__delete(root, deleteItem);
}

Node* __deleteMin(Node* r)
{
    if (r->left==nullptr)
        return r->right;
    else 
    {
        r->left=__deleteMin(r->left);
        return r;
    }

}
void deleteMin()
{
    if (root==nullptr)
        throw "Cannot delete min on an empty BST";
    else 
        root=__deleteMin(root);
}


Node* __getMin(Node* r)
{
    if (r->left==nullptr)
        return r;
    else 
    return __getMin(r->left);
}
Node* getMin()
{
    if (root==nullptr)
        throw "Cannot find min, as the tree is empty";
    else
        return __getMin(root);
}



~BinaryTree()
{
    queue<Node*> q;
    q.push(root);
    while(!q.empty())
    {
        Node* temp=q.front();
        q.pop();
        if (temp->left!=nullptr)
            q.push(temp->left);
        if (temp->right!=nullptr)
            q.push(temp->right);
        delete temp;    
    }
}
};
#endif