/*
Question) Write a function that takes a 
LinkedListStack object as an argument 
and returns the sum of all the elements in the stack.

*/

int sum_stack(LinkedListStack stack) {
int sum = 0;
while (!stack.is_empty()) {
sum += stack.top();
stack.pop();
}
return sum;
}