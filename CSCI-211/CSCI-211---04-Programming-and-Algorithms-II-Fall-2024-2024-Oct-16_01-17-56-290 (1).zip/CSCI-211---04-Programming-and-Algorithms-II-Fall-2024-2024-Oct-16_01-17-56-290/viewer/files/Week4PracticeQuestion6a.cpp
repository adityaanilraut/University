/*
Suppose you have a C++ class called Car that 
contains a pointer to a dynamically allocated object 
of type Engine, and you want to make sure that 
the memory for the Engine object is properly 
deallocated when a Car object is destroyed. 
Write a destructor for this class that frees 
up the memory allocated for the Engine object.
*/

class Engine {
public:
  Engine() { }
  ~Engine() { }
};

class Car {
private:
  Engine* engine;
public:
  Car() {
    engine = new Engine();
  }
  ~Car() {
    delete engine;
  }
};
