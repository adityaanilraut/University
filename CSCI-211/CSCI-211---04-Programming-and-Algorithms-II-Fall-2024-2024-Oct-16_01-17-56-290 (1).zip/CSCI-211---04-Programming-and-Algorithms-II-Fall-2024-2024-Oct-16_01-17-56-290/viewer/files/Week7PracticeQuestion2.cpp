/*
Implement a Stack using two queues
*/
#include <iostream>
#include <queue>
using namespace std;

class Stack {
public:
    void push(int x) {
        q1.push(x);
    }
    
    void pop() {
        // Move all elements except the last one to q2
        while (q1.size() > 1) {
            q2.push(q1.front());
            q1.pop();
        }
        // Remove the last element from q1
        q1.pop();
        // Move all elements back to q1
        while (!q2.empty()) {
            q1.push(q2.front());
            q2.pop();
        }
    }
    
    int top() {
        int val;
        // Move all elements to q2 except the last one
        while (!q1.empty()) {
            val = q1.front();
            q2.push(val);
            q1.pop();
        }
        // Move all elements back to q1
        while (!q2.empty()) {
            q1.push(q2.front());
            q2.pop();
        }
        return val;
    }
    
    bool empty() {
        return q1.empty();
    }
    
private:
    queue<int> q1, q2;
};

int main()
{
    // Create a new Stack object
    Stack *s1=new Stack();
    // Push some values onto the stack
    s1->push(1);
    s1->push(2);
    s1->push(3);
    s1->push(4);

    // Print the top value of the stack
    cout << s1->top() << endl;
    // Remove the top value from the stack
    s1->pop();
    // Print the new top value of the stack
    cout << s1->top() << endl;
    // Remove the top value from the stack
    s1->pop();
    // Print the new top value of the stack
    cout << s1->top() << endl;
    // Remove the top value from the stack
    s1->pop();
    // Print the new top value of the stack
    cout << s1->top() << endl;
    // Remove the top value from the stack
    s1->pop();
    
    // Free the memory allocated for the stack object
    delete s1;
    
    return 0;
}
