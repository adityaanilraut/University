#include <iostream>
using namespace std;

const int MAX_SIZE = 100; // maximum size of the priority queue

class PriorityQueue {
private:
    int arr[MAX_SIZE]; // array to store elements of the priority queue
    int size; // number of elements in the priority queue

public:
    PriorityQueue() { // constructor to initialize an empty priority queue
        size = 0;
    }

    void insert(int value) { // method to insert a new element into the priority queue
        if (size == MAX_SIZE) { // check if the priority queue is full
            cout << "Error: priority queue is full." << endl;
            return;
        }

        int i = size;
        while (i > 0 && value < arr[i - 1]) { // loop to find the correct position to insert the new element
            arr[i] = arr[i - 1]; // shift elements to the right to make room for the new element
            i--;
        }

        arr[i] = value; // insert the new element at the correct position
        size++; // increase the size of the priority queue
    }

    int remove() { // method to remove the highest-priority element from the priority queue
        if (size == 0) { // check if the priority queue is empty
            cout << "Error: priority queue is empty." << endl;
            return -1;
        }

        int value = arr[size - 1]; // get the highest-priority element (which is at the end of the array)
        size--; // decrease the size of the priority queue
        return value; // return the highest-priority element
    }

    int peek() { // method to peek at the highest-priority element without removing it
        if (size == 0) { // check if the priority queue is empty
            cout << "Error: priority queue is empty." << endl;
            return -1;
        }

        return arr[size - 1]; // return the highest-priority element (which is at the end of the array)
    }

    bool isEmpty() { // method to check if the priority queue is empty
        return size == 0;
    }
};

int main() {
    PriorityQueue pq; // create a new priority queue
    pq.insert(5); // insert some elements into the priority queue
    pq.insert(3);
    pq.insert(7);
    pq.insert(1);
    pq.insert(9);

    cout << "Priority queue peek: " << pq.peek() << endl; // peek at the highest-priority element

    while (!pq.isEmpty()) { // remove and print all elements from the priority queue
        cout << pq.remove() << " ";
    }

    cout << endl;

    return 0;
}
