/*
Suppose you have a C++ class called ThreeDMatrix 
that represents a 3D matrix of integers, 
with width, height, and depth being its dimensions. 
Write a destructor for this class that properly 
deallocates the memory for the matrix.
*/

class ThreeDMatrix {
private:
  int*** data;
  int width, height, depth;
public:
  ThreeDMatrix(int w, int h, int d) {
    width = w;
    height = h;
    depth = d;
    data = new int**[w];
    for (int i = 0; i < w; i++) {
      data[i] = new int*[h];
      for (int j = 0; j < h; j++) {
        data[i][j] = new int[d];
      }
    }
  }
  ~ThreeDMatrix() {
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        delete[] data[i][j];
      }
      delete[] data[i];
    }
    delete[] data;
  }
};
