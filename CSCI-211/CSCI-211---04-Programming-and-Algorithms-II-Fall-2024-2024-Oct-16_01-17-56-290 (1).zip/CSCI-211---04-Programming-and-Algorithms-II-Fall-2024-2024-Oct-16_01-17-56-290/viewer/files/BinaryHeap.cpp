#include <iostream>
#include <stdexcept>
using namespace std;
class BinaryHeap {
public:
    BinaryHeap(int capacity)
    {
        this->capacity=capacity;
        this->size=1;
        heap = new int[capacity]; 
    }

    ~BinaryHeap() {
        delete[] heap;
    }

    void insert(int data) {
        if (size == capacity-1) {
            throw runtime_error("Heap capacity exceeded.");
        }

        heap[size] = data;
        int i = size;

        // Percolate up
        while (i > 1 && heap[i / 2] > heap[i]) {
            swap(heap[i / 2], heap[i]);
            i /= 2;
        }
        size++;
    }

    int deleteMin() {
        if (size == 1) {
            throw runtime_error("Cannot delete from an empty heap.");
        }

        int minData = heap[1];
        heap[1] = heap[size-1];
        size--;

        // Percolate down
        int i = 1;
        while (true) {
            int minIndex = i;

            if (2 * i <= size && heap[minIndex] > heap[2 * i]) {
                minIndex = 2 * i;
            }

            if (2 * i + 1 <= size && heap[minIndex] > heap[2 * i + 1]) {
                minIndex = 2 * i + 1;
            }

            if (minIndex == i) {
                break;
            }

            swap(heap[i], heap[minIndex]);
            i = minIndex;
        }

        return minData;
    }

private:
    int* heap;
    int capacity;
    int size;
};

int main() {
    BinaryHeap heap(10); // Capacity of 10 elements
    heap.insert(50);
    heap.insert(30);
    heap.insert(20);
    heap.insert(40);
    heap.insert(70);
    heap.insert(60);
    heap.insert(80);
    heap.insert(10);

    cout << "Min element deleted: " << heap.deleteMin() << endl;
    cout << "Min element deleted: " << heap.deleteMin() << endl;
    cout << "Min element deleted: " << heap.deleteMin() << endl;
    //cout << "Min element deleted: " << heap.deleteMin() << endl;

    return 0;
}
