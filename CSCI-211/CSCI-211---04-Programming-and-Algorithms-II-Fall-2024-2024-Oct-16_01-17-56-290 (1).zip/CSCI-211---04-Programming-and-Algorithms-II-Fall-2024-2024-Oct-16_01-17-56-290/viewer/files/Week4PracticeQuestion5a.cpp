/*
Suppose you have a C++ class called Student 
that contains a dynamically allocated array 
of grades (as integers), and you want to 
make sure that this memory is properly 
deallocated when a Student object is destroyed. 
Write a destructor for this class that frees up the 
memory allocated for the grades array.
*/

class Student {
private:
  int* grades;
  int numGrades;
public:
  Student(int n) {
    numGrades = n;
    grades = new int[n];
  }
  ~Student() {
    delete[] grades;
  }
};
