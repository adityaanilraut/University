#ifndef __QUEUE__H
#define __QUEUE__H
#include <iostream>
using namespace std;
class Queue
{
    private:
    int* contents;
    int head;
    int tail;
    int size;
    int capacity;

    public:
    Queue(int capacity)
    {
            contents=new int[capacity];
            head=0;
            tail=0;
            size=0;
            this->capacity=capacity;
    }

    void enqueue(int data)
    {        
            contents[tail]=data;
            tail=tail+1;
            tail=tail%capacity;
            size=size+1;
            return; 
    }

    int dequeue()
    {
            if (size==0)
            {
                throw ("You cannot call dequeue on an empty queue");
            }
            else
            {
                int ret = contents[head];
                head=head+1;
                size=size-1;
                head=head%capacity;
                return ret;
            }
    }

    ~Queue()
    {
        delete[] contents; 
    }
};

int main()
{

    Queue *q1=new Queue(5);
    q1->enqueue(1);
    q1->enqueue(2);
    q1->enqueue(3);
    q1->enqueue(4);
    q1->enqueue(5);

    cout << q1->dequeue() <<endl;
    cout << q1->dequeue() <<endl;
    cout << q1->dequeue() <<endl;
    cout << q1->dequeue() <<endl;
    cout << q1->dequeue() <<endl;


}
#endif