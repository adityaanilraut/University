#include <iostream>
using namespace std;
/*
Write a C++ function that takes an array and its length as input and 
returns a boolean indicating whether the array is a palindrome or not. 
Your function should be efficient and avoid unnecessary checks.
*/


/*
What is the purpose of the "front" and "end" pointers in the "isPalindrome" function?
The "front" and "end" pointers are used to traverse the input array from both ends. The "front" pointer starts from the beginning of the array and moves towards the end, while the "end" pointer starts from the end of the array and moves towards the beginning. The pointers are used to check if the elements at the opposite ends of the array are equal.

How does the "isPalindrome" function determine if the input array is a palindrome?
The "isPalindrome" function determines if the input array is a palindrome by comparing the elements at opposite ends of the array. The "front" and "end" pointers are used to traverse the array from both ends. The function uses a while loop to keep checking if the elements pointed to by "front" and "end" are equal. If at any point, the elements are found to be unequal, the function immediately returns false, indicating that the array is not a palindrome. If the while loop completes execution, the function returns true, indicating that the array is a palindrome.

Advanced question, and we look at template classes a bit later in the term. However, I am teasing you a bit with this for now. 
Can you modify the "isPalindrome" function to handle arrays of any data type?
Yes, the "isPalindrome" function can be modified to handle arrays of any data type by using a template class in C++. The function can be declared as a template function, and the type of the array elements can be specified as a template parameter. This way, the function can be used with arrays of any data type, as long as the elements can be compared using the "!=" operator.
*/
bool isPalindrome(int arr[], int n) {
    int *front = arr;
    int *end = arr + n - 1;
    while (front < end) {
        if (*front != *end) {
            return false;
        }
        front++;
        end--;
    }
    return true;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    int arr[n];
    cout << "Enter the elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    if (isPalindrome(arr, n)) {
        cout << "The array is a palindrome" << endl;
    } else {
        cout << "The array is not a palindrome" << endl;
    }
    return 0;
}
