/*
Write a program to reverse an array of n numbers, 
where n is entered by the user. 
The numbers should be stored in an array, 
and the reversal should be performed using pointers.
*/

#include <iostream>

int main() {
    int n;

    std::cout << "Enter the number of elements: ";
    std::cin >> n;

    int *numbers = new int[n];

    std::cout << "Enter the numbers: ";
    for (int i = 0; i < n; i++) {
        std::cin >> *(numbers + i);
    }

    std::cout << "Reversed array: ";
    for (int i = n - 1; i >= 0; i--) {
        std::cout << *(numbers + i) << " ";
    }
    std::cout << std::endl;

    delete[] numbers;

    return 0;
}
