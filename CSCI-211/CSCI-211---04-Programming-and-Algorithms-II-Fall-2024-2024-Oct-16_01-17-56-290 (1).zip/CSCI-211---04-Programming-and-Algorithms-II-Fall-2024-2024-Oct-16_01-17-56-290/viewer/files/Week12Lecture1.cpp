#include <iostream>
using namespace std;
class Animal {
public:
    virtual ~Animal() {}
    virtual void make_sound() const = 0;
};

class Lion : public Animal {
public:
    void make_sound() const override {
        cout << "Roar!" << endl;
    }
};

class Elephant : public Animal {
public:
    void make_sound() const override {
        cout << "Trumpet!" << endl;
    }
};

class Snake : public Animal {
public:
    void make_sound() const override {
        cout << "Hiss!" << endl;
    }
};

int main() {
    Animal* zoo[3];

    zoo[0] = new Lion();
    zoo[1] = new Elephant();
    zoo[2] = new Snake();

    cout << "Welcome to the polymorphic zoo!" << std::endl;
    cout << "Here are the sounds our animals make:" << std::endl;

    for (Animal* const& animal : zoo) {
        animal->make_sound();
    }

    // Clean up the memory allocated for the animals.
    for (Animal*& animal : zoo) {
        delete animal;
        animal = nullptr;
    }

    return 0;
}