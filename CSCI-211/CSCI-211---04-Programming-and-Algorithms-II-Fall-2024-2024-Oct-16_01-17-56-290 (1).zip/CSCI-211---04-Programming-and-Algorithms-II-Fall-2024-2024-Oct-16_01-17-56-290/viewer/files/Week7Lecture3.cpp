#include <string>
#include <iostream>
#include <stack>
using namespace std;

int evalPostFixExpression(string pfe)
{
    stack<int> *s=new stack<int>();
    for (int i=0; i<pfe.length();i++)
    {
        if (isspace(pfe[i]))
        {
            continue;
        }
        if (isdigit(pfe[i]))
        {
            s->push(pfe[i]-'0');
        }
        else
        {
            int op2=s->top();
            s->pop();
            int op1=s->top();
            s->pop();
            switch (pfe[i])
            {
                case '+':
                    s->push(op1+op2);
                    break;
                case '*':
                    s->push(op1*op2);
                    break;
                case '-':
                    s->push(op1-op2);
                    break;
                case '/':
                    s->push(op1/op2);
                    break;
                default:
                    cerr <<"Invalid operator" <<endl;
                    return -1;
            }

        }
    }
    int ret=s->top();
    delete s;
    return ret;
}
int main()
{

string postfixExpression="2 3*4+";
cout << evalPostFixExpression(postfixExpression) <<endl;

}