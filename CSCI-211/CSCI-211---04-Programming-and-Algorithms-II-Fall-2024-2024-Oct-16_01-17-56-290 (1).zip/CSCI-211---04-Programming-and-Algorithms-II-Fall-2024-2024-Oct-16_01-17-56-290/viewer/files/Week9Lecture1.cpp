#include <iostream>
using namespace std;

// Define a LinkedList class
class LinkedList
{
    private:
    // Define a nested Node class
    class Node
    {
        public:
        int data; // Data held by the node
        Node *next; // Pointer to the next node in the list
        
        // Node constructor
        Node(int d, Node *n)
        {
            data = d;
            next = n;
        }
    };

    Node *head; // Pointer to the head of the linked list

    // Private recursive helper function to find the maximum value in the list
    int __getMax(Node *h)
    {
        if (h->next == nullptr)
        {
            return h->data;
        }
        int maxSoFar = __getMax(h->next);
        if (h->data > maxSoFar)
        {
            return h->data;
        }
        else
            return maxSoFar;
    }

    // Private recursive helper function to print the list in reverse order
    void __printR(Node *h)
    {
        if (h == nullptr)
            return;
        else 
        {
            __printR(h->next);
            cout << h->data << endl;
        }
    }

    // Private recursive helper function to print the list in forward order
    void __print(Node *h)
    {
        if (h == nullptr)
            return;
        else 
        {
            cout << h->data << endl;
            __print(h->next);
        }
    }

    // Private recursive helper function to calculate the length of the list
    int __length(Node *h)
    {
        if (h == nullptr)
            return 0;
        else return 1 + __length(h->next);
    }

    public:
    // Public function to print the list in reverse order
    void printR()
    {
        return __printR(head);
    }

    // Public function to print the list in forward order
    void print()
    {
        return __print(head);
    }

    // Public function to get the length of the list
    int length()
    {
        return __length(head);
    }

    // Public function to insert an element at the beginning of the list
    void insert(int d)
    {
        head = new Node(d, head);
    }

    // Public function to find the maximum value in the list
    int getMax()
    {
        if (head == nullptr)
            throw "Empty LinkedList";
        else
            return __getMax(head);
    }

};

int main()
{
    LinkedList l1;
    l1.insert(1);
    l1.insert(12);
    l1.insert(3);
    l1.insert(4);
    l1.insert(5);

    // Display the length of the list
    cout << "The length of the linked list is " << l1.length() << endl;
    // Print the list in forward order
    cout << "Print in forward" << endl;
    l1.print();
    // Print the list in reverse order
    cout << "Print in reverse" << endl;
    l1.printR();
    // Find and display the maximum value in the list
    cout << "Max in Linked List" << endl;
    cout << l1.getMax() << endl;
}
