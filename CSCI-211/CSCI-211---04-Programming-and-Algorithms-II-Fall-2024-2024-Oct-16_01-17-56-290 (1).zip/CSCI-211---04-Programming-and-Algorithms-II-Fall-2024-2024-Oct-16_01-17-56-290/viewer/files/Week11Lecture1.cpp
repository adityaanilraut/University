#include "Shape.h"
#include "Circle.h"
#include "Square.h"

int main() {
    Circle circle1, circle2;
    Square square1, square2;

    // Creating an array of Shape pointers
    Shape *shapes[] = {&circle1, &square1, &circle2, &square2};

    // Loop to traverse the array and call the draw() function
    for (Shape *shape : shapes) {
        shape->draw();
    }

    return 0;
}
