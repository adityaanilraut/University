/*
Write a C++ function that takes an integer number as input and returns 
a boolean indicating whether the number is a palindrome or not.
*/

/*
What does the "isPalindrome" function determine in the given code?
The "isPalindrome" function determines if an integer number is a 
palindrome or not. The function takes an integer number as input and 
returns a boolean indicating whether the number is a palindrome or not.

How does the function determine if a number is a palindrome or not?
The function determines if a number is a palindrome or not by 
first checking if the input number is negative. 
If the number is negative, the function immediately returns false, 
as negative numbers can't be palindromes. If the number is positive, 
the function calculates the reverse of the number by repeatedly 
taking the modulo of the number by 10 and adding the result to a 
running total that is multiplied by 10 at each iteration. 
The function then compares the original number with the reverse and 
returns true if they are equal, indicating that the number is a 
palindrome, or false otherwise.
*/

bool isPalindrome(int x) {
    if (x < 0) {
        return false;
    }
    int original = x;
    int reverse = 0;
    while (x != 0) {
        reverse = reverse * 10 + x % 10;
        x /= 10;
    }
    return original == reverse;
}
