#include <iostream>
#include "video.h"

using namespace std;

/*
What is the purpose of the class Video in the code?
The purpose of the class Video is to define a blueprint for creating objects that represent video information, including the title, URL, comment, length, and rating of a video.

What are the member variables in the class Video?
The member variables in the class Video are m_title, m_url, m_comment, m_length, and m_rating. These variables store the information that defines a video.

What is the purpose of the Video constructor in the code?
The Video constructor is used to create and initialize Video objects. There are two constructors defined for the Video class, a default constructor and a constructor that takes 5 arguments. The default constructor does not perform any initialization, while the constructor with arguments is used to initialize the member variables of a Video object with the values passed in as arguments.

What does the setName() function do?
The setName() function is used to set the title of a Video object. It takes a string argument representing the title and sets the value of the m_title member variable to the value of this argument.

What does the print() function do?
The print() function is used to display information about a Video object. It prints the title and URL of the video to the console using the cout statement.
*/

Video::Video()
{

}
Video::Video(string title, string url, string comment, float length, int rating)
{
    m_title=title;
    m_url=url;
    m_comment=comment;
    m_length=length;
    m_rating=rating;
}

void Video::print()
{
    cout << "The title of the movie is " << m_title <<endl;
    cout << "The url of the movie is " << m_url <<endl;

}

void Video::setName(string title)
{
    m_title=title;
}