#include <iostream>
#include <string>
using namespace std;
/*
What does the function isPalindrome do?
The function isPalindrome checks if a given string s is a palindrome or not.

How does the function isPalindrome determine if a string is a palindrome or not?
The function isPalindrome iterates through the string s and checks if the characters at the corresponding positions at the start and end of the string are equal or not. If they are not equal, the function returns false, indicating that the string is not a palindrome. If all the characters are equal, the function returns true, indicating that the string is a palindrome.

Why is the variable n initialized in the main function before the strings are input?
The variable n is initialized in the main function to determine the number of strings that will be input. This information is used to dynamically allocate an array of strings using the new operator.

Why is the for loop in the isPalindrome function only looping through half the length of the string?
The for loop in the isPalindrome function only loops through half the length of the string because if the string is not a palindrome, checking half the length of the string is sufficient to determine that it is not a palindrome. This is because a string is a palindrome if and only if the characters at corresponding positions at the start and end of the string are equal.

What does the line cin >> strings[i]; do in the main function?
The line cin >> strings[i]; in the main function inputs a string from the standard input and stores it in the ith element of the strings array.

Why is the array strings dynamically allocated using the new operator?
The array strings is dynamically allocated using the new operator because the number of strings to be input is determined at runtime, and the size of the array needs to be determined dynamically based on this number. The new operator allows us to allocate memory dynamically during runtime.


*/
bool isPalindrome(string s) {
  int n = s.length();
  for (int i = 0; i < n / 2; i++) {
    if (s[i] != s[n - i - 1]) {
      return false;
    }
  }
  return true;
}

int main() {
  int n;
  cout << "Enter the number of strings: ";
  cin >> n;

  string *strings = new string[n];
  cout << "Enter the strings: ";
  for (int i = 0; i < n; i++) {
    cin >> strings[i];
  }

  for (int i = 0; i < n; i++) {
    if (isPalindrome(strings[i])) {
      cout << strings[i] << " is a palindrome." << std::endl;
    } else {
      cout << strings[i] << " is not a palindrome." << std::endl;
    }
  }

  delete[] strings;
  return 0;
}