/*
Create a class called "Fraction" with attributes numerator and denominator. 
Include methods to add, subtract, multiply, and divide fractions.
No pointers are involved in this code. 
*/

#include <iostream>
using namespace std;

class Fraction {
    private:
        int numerator;
        int denominator;

    public:
        void setNumerator(int num) {
            numerator = num;
        }
        void setDenominator(int den) {
            denominator = den;
        }
        int getNumerator() {
            return numerator;
        }
        int getDenominator() {
            return denominator;
        }
        Fraction add(Fraction f) {
            Fraction result;
            result.setNumerator(numerator*f.denominator + f.numerator*denominator);
            result.setDenominator(denominator*f.denominator);
            return result;
        }
        Fraction subtract(Fraction f) {
            Fraction result;
            result.setNumerator(numerator*f.denominator - f.numerator*denominator);
            result.setDenominator(denominator*f.denominator);
            return result;
        }
        Fraction multiply(Fraction f) {
            Fraction result;
            result.setNumerator(numerator*f.numerator);
            result.setDenominator(denominator*f.denominator);
            return result;
        }
        Fraction divide(Fraction f) {
            Fraction result;
            result.setNumerator(numerator*f.denominator);
            result.setDenominator(denominator*f.numerator);
            return result;
        }
};

int main() {
    Fraction f1, f2;
    f1.setNumerator(1);
    f1.setDenominator(2);
    f2.setNumerator(3);
    f2.setDenominator(4);

    Fraction result = f1.add(f2);
    cout << f1.getNumerator() << "/" << f1.getDenominator() << " + " << f2.getNumerator() << "/" << f2.getDenominator() << " = " << result.getNumerator() << "/" << result.getDenominator() << endl;

    result = f1.subtract(f2);
   
