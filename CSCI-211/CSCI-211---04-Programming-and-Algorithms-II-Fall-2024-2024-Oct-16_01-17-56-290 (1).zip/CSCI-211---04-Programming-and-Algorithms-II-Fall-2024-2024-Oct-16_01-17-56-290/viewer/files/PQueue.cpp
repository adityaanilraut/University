#include <iostream>
using namespace std;

class PQueue {
private:
    // Node inner class represents an element in the priority queue
    class Node {
    public:
        int data;       // Data of the element
        int priority;   // Priority of the element
        Node* next;     // Pointer to the next node in the list

        // Node constructor initializing data, priority, and next pointer
        Node(int data, int priority, Node* next) : data(data), priority(priority), next(next) {}
    };

    Node* head;  // Pointer to the head node of the priority queue

public:
    // Default constructor initializes the head node to nullptr (empty list)
    PQueue() : head(nullptr) {}

    // Destructor deallocates memory used by the nodes in the priority queue
    ~PQueue() {
        while (head) {
            dequeue();
        }
    }

    // enqueue() function inserts an element with given data and priority into the priority queue
    // The element is inserted according to its priority in descending order (highest priority first)
    // If two elements have the same priority, they maintain their relative order (stable priority queue)
    void enqueue(int data, int priority) {
        Node* newNode = new Node(data, priority, nullptr);

        // If the list is empty or the priority is higher than the head node's priority,
        // insert the new node at the beginning of the list
        if (!head || priority > head->priority) {
            newNode->next = head;
            head = newNode;
        } else {
            // Traverse the list to find the correct position for the new node
            Node* current = head;
            while (current->next && priority <= current->next->priority) {
                current = current->next;
            }
            // Insert the new node after the current node
            newNode->next = current->next;
            current->next = newNode;
        }
    }

    // dequeue() function removes and returns the data of the element with the highest priority
    // If the priority queue is empty, an exception is thrown
    int dequeue() {
        if (!head) {
            throw runtime_error("Empty priority queue");
        }

        // Remove the head node from the list and save its data
        Node* temp = head;
        int data = temp->data;
        head = head->next;

        // Deallocate memory used by the removed node and return its data
        delete temp;
        return data;
    }

    // isEmpty() function checks if the priority queue is empty
    // Returns true if the head node is nullptr (no elements in the list), false otherwise
    bool isEmpty() {
        return head == nullptr;
    }
};

int main() {
    PQueue pq;

    // Enqueue elements with their priorities
    pq.enqueue(4, 1);
    pq.enqueue(5, 2);
    pq.enqueue(6, 3);
    pq.enqueue(2, 0);

    // Dequeue and print elements in order of their priority (highest priority first)
    while (!pq.isEmpty()) {
        cout << pq.dequeue() << endl;
    }

    return 0;
}
