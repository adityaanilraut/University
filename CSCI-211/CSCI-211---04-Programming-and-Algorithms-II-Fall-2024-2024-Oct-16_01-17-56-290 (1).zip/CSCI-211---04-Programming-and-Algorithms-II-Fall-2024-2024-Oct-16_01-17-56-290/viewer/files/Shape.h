#ifndef SHAPEH
#define SHAPEH
#include <iostream>
using namespace std;

class Shape {
public:
    virtual void draw() const {
       cout << "Drawing a generic shape" << endl;
    }
};
#endif