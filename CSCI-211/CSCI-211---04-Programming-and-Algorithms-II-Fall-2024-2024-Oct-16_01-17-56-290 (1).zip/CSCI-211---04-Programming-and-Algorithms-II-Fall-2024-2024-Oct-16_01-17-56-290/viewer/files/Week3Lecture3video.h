#ifndef VIDEO_H
#define VIDEO_H

#include <string>
using namespace std;

/*
What is the purpose of the Video class in the code?
The Video class is used to represent video objects, which have a title, URL, comment, length, and rating. The class provides a constructor and various methods for setting and accessing the properties of a Video object.

What is the purpose of the Video() constructor in the code?
The Video() constructor is a default constructor that is used to create Video objects without initializing the properties. When a Video object is created using this constructor, the properties will have their default values (e.g. empty strings, 0 length, 0 rating).

What is the purpose of the Video(string title, string url, string comment, float length, int rating) constructor in the code?
The Video(string title, string url, string comment, float length, int rating) constructor is a parameterized constructor that is used to create Video objects and initialize their properties. When a Video object is created using this constructor, the properties are initialized with the values passed in as arguments.

What is the purpose of the print() method in the code?
The print() method is used to print the properties of a Video object to the console. This method can be called on a Video object to display its title, URL, comment, length, and rating.

What is the purpose of the setName() method in the code?
The setName() method is used to set the title of a Video object. This method takes a single argument, a string representing the new title, and updates the m_title property of the Video object.
*/

class Video
{

    private:
        string m_title;
        string m_url;
        string m_comment;
        double m_length;
        int m_rating;

    public:
    Video();
    Video(string title, string url, string comment, float length, int rating);
    void print(); //prototype 
    void setName(string title);

};
#endif 