#include "Stack.h" // include the header file for the Stack class
#include <string> // include the header file for the string class
#include <cstring> // include the header file for the C-style string functions
#include <iostream> // include the header file for standard input/output functions
using namespace std;

int main() {
    string lefty = "([{"; // define a string of opening brackets
    string righty = ")]}"; // define a string of closing brackets
    string test1 = "((((([])))))[][][]))))"; // define a test string with mismatched brackets
    char arr[test1.length() + 1]; // declare a character array with enough space to hold the test string
    strcpy(arr, test1.c_str()); // copy the contents of the test string to the character array
    Stack *l1 = new Stack(); // create a new Stack object to hold the brackets
    for (int i = 0; i < test1.length(); i++) { // loop through each character in the test string
        int index = lefty.find(arr[i]); // check if the current character is an opening bracket
        if (index != -1) { // if the current character is an opening bracket
            l1->push(arr[i]); // push it onto the stack
        } else { // if the current character is a closing bracket
            try {
                if (lefty.find(l1->pop()) == righty.find(arr[i])) { // check if the top of the stack matches the current character
                    continue; // if they match, continue to the next character
                } else { // if they don't match
                    cout << "Failed!"; // print an error message
                    return -1; // exit the program with an error code
                }
            } catch (const char *msg) { // catch any exceptions thrown by the Stack class. Something like "(())))))))))))"
                cout << "Failed!"; // print an error message
                return -1; // exit the program with an error code
            }
        }
    }
    if (l1->getSize() != 0) { // if there are still unmatched opening brackets on the stack. Something like "((((((((((())"
        cout << "Failed!"; // print an error message
        return -1; // exit the program with an error code
    }
    cout << "Passed!"; // print a success message
    return 0; // exit the program with a success code
}
