#include <iostream>
#include <chrono>
using namespace std;

/*
What does the stack_func() function do?
The stack_func() function creates a variable x on the stack and increments its value by 1.

What does the heap_func() function do?
The heap_func() function creates a pointer p on the stack and creates an integer object 10 on the heap. The pointer points at this integer object. The value of the integer pointed to by p is then incremented by 1, and p is freed from memory by calling delete.

What is the purpose of the chrono library used in this code?
The chrono library is used to measure the execution time of both the stack_func() and heap_func() functions. The chrono::high_resolution_clock is used to get the current time, and the chrono::duration_cast function is used to convert the elapsed time to microseconds.

What is the purpose of the two for loops in the main function?
The two for loops are used to measure the execution time of the stack_func() and heap_func() functions. The first for loop calls stack_func() 100000000 times, and the second for loop calls heap_func() 100000000 times. The execution time of each loop is measured and displayed on the screen in microseconds.

How does the execution time of the stack_func() and heap_func() functions compare?
The exact comparison of the execution time of the stack_func() and heap_func() functions can vary depending on the machine and environment in which the code is executed. In general, functions that use the stack tend to have faster execution times than functions that use the heap, because the stack is faster and more predictable than the heap.

*/
void stack_func() {
    int x = 10;
    x++;
}

void heap_func() {
    int *p = new int;
    *p = 10;
    (*p)++;
    delete p;
}

int main() {
    auto start = chrono::high_resolution_clock::now();
    for (int i = 0; i < 100000000; i++) {
        stack_func();
    }
    auto end = chrono::high_resolution_clock::now();
    cout << "Stack: " << chrono::duration_cast<chrono::microseconds>(end - start).count() << "us\n";

    start = chrono::high_resolution_clock::now();
    for (int i = 0; i < 100000000; i++) {
        heap_func();
    }
    end = chrono::high_resolution_clock::now();
    std::cout << "Heap: " << chrono::duration_cast<chrono::microseconds>(end - start).count() << "us\n";
}