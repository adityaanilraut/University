/*
Implement a class "Rectangle" that has two private data members "length" and "width". 
The class should have a constructor that takes two arguments and initializes 
the data members, and two member functions "getArea" and "getPerimeter" 
that return the area and perimeter of the rectangle, respectively.
*/

#include <iostream>

class Rectangle
{
    int length, width;

public:
    Rectangle(int l, int w)
    {
        length = l;
        width = w;
    }

    int getArea()
    {
        return length * width;
    }

    int getPerimeter()
    {
        return 2 * (length + width);
    }
};

int main()
{
    int l, w;
    std::cout << "Enter length and width of the rectangle: ";
    std::cin >> l >> w;

    Rectangle *rect = new Rectangle(l, w);
    std::cout << "Area of the rectangle: " << rect->getArea() << std::endl;
    std::cout << "Perimeter of the rectangle: " << rect->getPerimeter() << std::endl;

    delete rect;

    return 0;
}
