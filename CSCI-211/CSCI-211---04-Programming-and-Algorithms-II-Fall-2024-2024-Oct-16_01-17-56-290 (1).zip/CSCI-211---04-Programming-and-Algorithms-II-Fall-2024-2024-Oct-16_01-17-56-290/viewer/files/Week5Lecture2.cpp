#include <iostream>
using namespace std;

class LinkedListStack {
private:
    // Inner class representing a node in the linked list
    class Node {
    public:
        int data;   // data stored in the node
        Node* next; // pointer to the next node
        // Constructor to initialize the data and next pointers of the node
        Node(int d) {
            data = d;
            next = nullptr;
        }
        // Destructor for the node (currently empty)
        ~Node() { }
    };
    Node* head; // Pointer to the head node of the linked list
public:
    // Constructor for the stack, initializing the head pointer to null
    LinkedListStack() {
        head = nullptr;
    }
    // Destructor for the stack, freeing up all the dynamically allocated memory
    ~LinkedListStack() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
    // Method to add a new element to the top of the stack
    void push(int x) {
        // Create a new node with the given data
        Node* newNode = new Node(x);
        // Set the next pointer of the new node to point to the current top node
        newNode->next = head;
        // Set the head pointer to point to the new node, making it the new top
        head = newNode;
    }
    // Method to remove the top element from the stack
    void pop() {
        // Check if there is at least one element in the stack
        if (head != nullptr) {
            // Create a temporary pointer to the current top node
            Node* temp = head;
            // Set the head pointer to point to the next node in the list
            head = head->next;
            // Delete the original top node
            delete temp;
        }
    }
    // Method to return the value of the top element in the stack
    int top() {
        // Check if there is at least one element in the stack
        if (head != nullptr) {
            // Return the data stored in the current top node
            return head->data;
        }
        // Return 0 if the stack is empty
        return 0;
    }
};

int main()
{
    // Create a new LinkedListStack object
    LinkedListStack *l = new LinkedListStack();

    // Push 5 elements onto the stack
    l->push(1);
    l->push(2);
    l->push(3);
    l->push(4);
    l->push(5);
    
    // Print the value of the top element in the stack
    cout << l->top() << endl;
    // Remove the top element from the stack
    l->pop();
    // Print the value of the new top element in the stack
    cout << l->top() << endl;
    // Remove the top element from the stack
    l->pop();
    // Print the value of the new top element in the stack
    cout << l->top() << endl;
    // Remove the top element from the stack
    l->pop();
    // Print the value of the new top element in the stack
    cout << l->top() << endl;
    // Remove the top element from the stack
    l->pop();
    // Print the value of the new top element in the stack (should be 0)
    cout << l->top() << endl;
    
    // Delete the LinkedListStack object and free up the dynamically allocated memory
    delete l;

    return 0;
}


/*
Question) 
Write a program that reads a sequence of 
commands (either push or pop) from standard 
input and performs those commands on a 
LinkedListStack object, printing 
the value of the top element after each command. 
Terminate the program when the user enters 
an empty line.

Answer) 

int main() {
    LinkedListStack stack;
    string command;
    while (getline(cin, command)) {
        if (command == "") {
            break;
        } else if (command == "push") {
            int x;
            cin >> x;
            stack.push(x);
        } else if (command == "pop") {
            stack.pop();
        }
        cout << stack.top() << endl;
    }
    return 0;
}


Question ) 

Write a function that takes a 
LinkedListStack object as an argument 
and returns a new LinkedListStack object 
with the elements of the original stack in 
reverse order.

Answer) 

LinkedListStack reverse_stack(LinkedListStack stack) {
    LinkedListStack reversed_stack;
    while (!stack.is_empty()) {
        reversed_stack.push(stack.top());
        stack.pop();
    }
    return reversed_stack;
}


Question) 

Add a method to the LinkedListStack 
class called is_empty that returns true 
if the stack is empty and false otherwise.

bool is_empty() {
    return head == nullptr;
}

*/