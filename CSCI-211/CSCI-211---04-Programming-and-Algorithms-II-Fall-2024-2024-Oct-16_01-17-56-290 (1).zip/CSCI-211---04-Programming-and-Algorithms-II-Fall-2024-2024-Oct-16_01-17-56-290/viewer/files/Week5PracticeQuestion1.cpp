/*
Question) Write a program that uses the LinkedListStack 
class to check whether a given string is a palindrome 
or not. 
A string is a palindrome if it reads the same 
forwards and backwards (ignoring spaces and punctuation). 
The program should read a string from standard 
input and print "Yes" if the string is a palindrome 
and "No" otherwise.
*/


#include <iostream>
#include <string>
#include <cctype>
using namespace std;

bool is_palindrome(string str) {
LinkedListStack stack;
for (char c : str) {
if (isalpha(c)) {
stack.push(tolower(c));
}
}
for (char c : str) {
if (isalpha(c)) {
if (tolower(c) != stack.top()) {
return false;
}
stack.pop();
}
}
return true;
}

int main() {
string str;
getline(cin, str);
if (is_palindrome(str)) {
cout << "Yes" << endl;
} else {
cout << "No" << endl;
}
return 0;
}
/*

Note: The is_palindrome function 
first pushes all the alphabetic characters 
(in lowercase) of the string onto a stack. 
It then compares each character of the string 
to the top of the stack, popping the stack as it goes. 
If the characters do not match, the function returns false. 
If the entire string is processed without finding a mismatch, 
the function returns true.
*/