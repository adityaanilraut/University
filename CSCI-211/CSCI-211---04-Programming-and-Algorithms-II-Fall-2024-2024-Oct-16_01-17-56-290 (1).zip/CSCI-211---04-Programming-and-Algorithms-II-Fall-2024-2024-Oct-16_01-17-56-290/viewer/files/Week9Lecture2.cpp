#include <iostream>
using namespace std;

// function1: No loops, prints "Hello World" once. 
//Time complexity: O(1) - Constant
void function1()
{
    cout << "Hello World";
}

// function2: No loops, prints "Hello World" once, regardless of input n. 
//Time complexity: O(1) - Constant
void function2(int n)
{
    cout << "Hello World";
}

// function3: Runs 5 times, prints "Hello World" with a newline each time. 
//Time complexity: O(1) - Constant
void function3()
{
    int i=0;
    while(i<5)
    {
        cout << "Hello World" <<endl;
        i=i+1;
    }
}

// function4: Runs 5 times, prints "Hello World" with a newline each time, regardless of input n. 
//Time complexity: O(1) - Constant
void function4(int n)
{
    int i=0;
    while(i<5)
    {
        cout << "Hello World" <<endl;
        i=i+1;
    }
}

// function5: Runs n times, prints "Hello World" with a newline each time. 
//Time complexity: O(n) - Linear
void function5 (int n)
{
    int i =0 ;
    while(i<n)
    {
        cout << "Hello World" <<endl;
        i=i+1;
    }
}

// function6: Outer loop runs 5 times, inner loop runs 5 times for each outer loop iteration. 
//Time complexity: O(1) - Constant (O(25) specifically)
void function6(int n)
{
    int i=0;
    while(i<5)
    {
        int j=0;
        while(j<5)
        {
            cout << "Hello World" <<endl;
            j=j+1;
        }
        i=i+1;
    }
}

// function7: Outer loop runs n times, inner loop runs n times for each outer loop iteration. 
//Time complexity: O(n^2) - Quadratic
void function7(int n)
{
    int i=0;
    while(i<n)
    {
        int j=0;
        while(j<n)
        {
            cout << "Hello World" <<endl;
            j=j+1;
        }
        i=i+1;
    }
}
