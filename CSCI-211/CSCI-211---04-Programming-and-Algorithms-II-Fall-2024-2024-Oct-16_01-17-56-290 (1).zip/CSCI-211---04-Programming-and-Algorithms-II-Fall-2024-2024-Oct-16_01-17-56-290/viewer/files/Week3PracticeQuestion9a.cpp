/*
Write a program to find the second largest number in an array of n numbers, 
where n is entered by the user. 
The numbers should be stored in an array, and the second largest 
number should be found using pointers.
*/

#include <iostream>

int main()
{
    int n, largest, secondLargest;

    std::cout << "Enter the number of elements: ";
    std::cin >> n;

    int *numbers = new int[n];

    std::cout << "Enter the numbers: ";
    for (int i = 0; i < n; i++)
    {
        std::cin >> *(numbers + i);
    }

    largest = *numbers;
    secondLargest = *numbers;

    for (int i = 0; i < n; i++)
    {
        if (*(numbers + i) > largest)
        {
            secondLargest = largest;
            largest = *(numbers + i);
        }
        else if (*(numbers + i) > secondLargest && *(numbers + i) != largest)
        {
            secondLargest = *(numbers + i);
        }
    }

    std::cout << "Second largest number: " << secondLargest << std::endl;

    delete[] numbers;

    return 0;
}
