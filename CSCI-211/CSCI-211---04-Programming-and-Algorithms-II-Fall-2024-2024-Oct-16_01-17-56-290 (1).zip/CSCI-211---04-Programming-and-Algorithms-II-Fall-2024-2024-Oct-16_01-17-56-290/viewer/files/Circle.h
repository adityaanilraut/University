#ifndef CIRCLEH
#define CIRCLEH
#include "Shape.h"
class Circle : public Shape {
public:
    void draw() const override {
        cout << "Drawing a circle" << endl;
    }
};
#endif