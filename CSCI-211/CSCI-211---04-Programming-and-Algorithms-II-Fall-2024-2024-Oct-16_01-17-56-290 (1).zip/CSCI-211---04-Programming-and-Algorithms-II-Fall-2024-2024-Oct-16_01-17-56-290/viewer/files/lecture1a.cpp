#include <iostream>
using namespace std;
/*
What is the purpose of the function func1() in the code?
The purpose of the function func1() is to take three inputs, an integer x, a character a, and a pointer to an integer (ptr), and return the value 6.

What does the function func1() do with the input parameters?
The function func1() does not do anything with the input parameters except for storing them in local variables. The integer x is stored in a local variable named x, the character a is stored in a local variable named a, and the pointer ptr is stored in a local variable named ptr.

What does the main function do with the returned value from func1()?
The main function stores the returned value from func1() in a local variable named result, and then prints the value of result to the console using the cout statement.

What is the value of the output that is returned by func1()?
The value of the output returned by func1() is 6. This value is assigned to the local variable output within the function and then returned when the function is finished executing.

What is the purpose of the string "hello world" in the function func1()?
The string "hello world" in the function func1() serves as an example of a local variable that is not used in the rest of the function. It is likely included in the code as a placeholder for additional functionality that could be added in the future.

What happens to the memory that is allocated for the local variables in the function "func1"?
The memory that is allocated for the local variables in the function "func1" is automatically deallocated when the function returns.
*/

int func1(int x,char a,int *ptr)
{
    string str1="hello world";
    int output = 6;
    return output;
}
int main()
{
    int x=5;
    char a='a';
    int *ptr=&x;

    int result=func1(x,a,ptr);
    cout <<result;

}