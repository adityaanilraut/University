#include <iostream>

class Complex {
public:
    Complex(double real, double imag) : real_(real), imag_(imag) {}

    // Overloading the + operator
    Complex operator+(const Complex &other) const {
        double real_result = real_ + other.real_;
        double imag_result = imag_ + other.imag_;
        return Complex(real_result, imag_result);
    }

    void print() const {
        std::cout << real_ << " + " << imag_ << "i" << std::endl;
    }

private:
    double real_;
    double imag_;
};

int main() {
    Complex num1(3, 4);
    Complex num2(1, 2);

    Complex sum = num1 + num2;
    sum.print();  // Output: 4 + 6i

    return 0;
}
