#ifndef __QUEUE__H
#define __QUEUE__H
#include "Stack.h"

class Queue
{
    private:
     Stack *l1;
     Stack *l2;

     int size;

    public:
    Queue()
    {
        l1=new Stack();
        l2=new Stack();
        size=0;
    }

    void enqueue(int data)
    {
        l1->push(data);
        size=size+1;
    }

    int dequeue()
    {
        if (l2->getSize()==0)
        {
                while(l1->getSize()!=0)
                {
                    l2->push(l1->pop());
                }
        }
        return l2->pop();
        
    }

    ~Queue()
    {
        delete l1;
        delete l2;
    }

};

int main()
{
    Queue *q1 = new Queue();
    q1->enqueue(1);
    q1->enqueue(2);
    q1->enqueue(3);
    q1->enqueue(4);
    q1->enqueue(5);

    cout << q1->dequeue() <<" "<<endl; //1
    cout << q1->dequeue() <<" "<<endl; //2 
    cout << q1->dequeue() <<" "<<endl; //3
    cout << q1->dequeue() <<" "<<endl; //4
    cout << q1->dequeue() <<" "<<endl; //5

}
#endif