/*
Suppose you have a C++ class called Matrix that 
represents a 2D matrix of integers, with rows and cols 
being its dimensions. 
Write a destructor for this class that frees 
up the memory allocated for the matrix.
*/

class Matrix {
private:
  int** data;
  int rows, cols;
public:
  Matrix(int r, int c) {
    rows = r;
    cols = c;
    data = new int*[r];
    for (int i = 0; i < r; i++) {
      data[i] = new int[c];
    }
  }
  ~Matrix() {
    for (int i = 0; i < rows; i++) {
      delete[] data[i];
    }
    delete[] data;
  }
};
