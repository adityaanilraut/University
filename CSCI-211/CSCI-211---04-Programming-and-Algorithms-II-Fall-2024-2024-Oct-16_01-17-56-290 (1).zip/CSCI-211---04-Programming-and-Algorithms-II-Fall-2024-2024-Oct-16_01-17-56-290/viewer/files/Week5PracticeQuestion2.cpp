/*
Question) Write a program that reads a sequence of 
integers from standard input and uses a LinkedListStack 
object to check if the sequence is a palindrome.
*/


#include <iostream>
#include <string>
#include <sstream>
using namespace std;

bool is_palindrome(string str) {
LinkedListStack stack;
int len = str.length();
for (int i = 0; i < len/2; i++) {
stack.push(str[i]);
}
for (int i = (len+1)/2; i < len; i++) {
if (stack.top() != str[i]) {
return false;
}
stack.pop();
}
return true;
}

int main() {
string input;
while (getline(cin, input)) {
stringstream ss(input);
int num;
LinkedListStack stack;
while (ss >> num) {
stack.push(num);
}
bool is_pal = true;
while (!stack.is_empty()) {
if (stack.top() != num) {
is_pal = false;
break;
}
stack.pop();
}
if (is_pal) {
cout << "The sequence is a palindrome." << endl;
} else {
cout << "The sequence is not a palindrome." << endl;
}
}
return 0;
}