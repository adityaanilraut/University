/*
Create a class called "Circle" with attribute radius. 
Include a method to calculate the area of the circle. 
Use a pointer to create an object of this class.
*/

#include <iostream>
using namespace std;

class Circle {
    private:
        double radius;

    public:
        Circle(double r) {
            radius = r;
        }
        double getArea() {
            return 3.14159 * radius * radius;
        }
};

int main() {
    Circle* circlePtr;
    Circle circleObj(5.0);
    circlePtr = &circleObj;

    cout << "The area of the circle is " << circlePtr->getArea() << endl;
    return 0;
}
