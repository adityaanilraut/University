#include <iostream>
using namespace std;
/*
Write a recursive function that finds the greatest common divisor (GCD) of two numbers using the Euclidean algorithm.
*/
int gcd(int a, int b) {
    if (b == 0) {
        return a;
    }
    return gcd(b, a % b);
}

int main() {
    int a = 56, b = 98;
    cout << "The GCD of " << a << " and " << b << " is " << gcd(a, b) << endl;
    return 0;
}
