/*
Implement a class "Student" that has a private data member "name" (a string) and a 
private data member "marks" (an array of 5 integers). 
The class should have a constructor that takes a string argument and 
initializes the "name" data member, and another constructor 
that takes two arguments: a string and an array of 5 integers. 
The latter constructor should initialize both the "name" and "marks" data members. 
The class should also have a member function "display" that displays the name 
and marks of the student.

*/

#include <iostream>
#include <string>

class Student
{
    std::string name;
    int marks[5];

public:
    Student(std::string n)
    {
        name = n;
    }

    Student(std::string n, int m[5])
    {
        name = n;
        for (int i = 0; i < 5; i++)
        {
            marks[i] = m[i];
        }
    }

    void display()
    {
        std::cout << "Name: " << name << std::endl;
        std::cout << "Marks: ";
        for (int i = 0; i < 5; i++)
        {
            std::cout << marks[i] << " ";
        }
        std::cout << std::endl;
    }
};

int main()
{
    std::string name;
    int marks[5];

    std::cout << "Enter name: ";
    std::cin >> name;
    std::cout << "Enter marks: ";
    for (int i = 0; i < 5; i++)
    {
        std::cin >> marks[i];
    }

    Student *student = new Student(name, marks);
    student->display();

    delete student;

    return 0;
}
