#include <iostream>
using namespace std;
/*
Write a recursive function that calculates the power of a number.
*/
double power(double base, int exponent) {
    if (exponent == 0) {
        return 1;
    } else if (exponent < 0) {
        return 1 / (base * power(base, -exponent - 1));
    } else {
        return base * power(base, exponent - 1);
    }
}

int main() {
    double base = 2;
    int exponent = 3;
    cout << base << " to the power of " << exponent << " is " << power(base, exponent) << endl;
    return 0;
}
