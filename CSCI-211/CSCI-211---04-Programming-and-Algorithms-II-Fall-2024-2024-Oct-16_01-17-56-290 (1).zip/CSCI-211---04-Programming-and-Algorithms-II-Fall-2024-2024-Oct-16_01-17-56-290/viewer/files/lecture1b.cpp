#include <iostream>
using namespace std;
/*
What is the difference between stack and heap memory?
The stack is a memory area used to store function calls and local variables. It is fast, but limited in size. The heap, on the other hand, is a memory area used to store objects that are dynamically allocated in your program and it has a larger size than the stack.

What is the purpose of the line "int x=5"?
The line "int x=5" declares an integer variable named "x" and assigns the value 5 to it. The "x" and 5 are both stored on the stack.

What is the purpose of the line "int *ptr1=new int()"?
The line "int *ptr1=new int()" declares a pointer named "ptr1" that points to an integer object. The "ptr1" is stored on the stack, and it contains an address on the heap to an int object.

What is the difference between "ptr[i]" and "*(ptr+i)"?
Both "ptr[i]" and "(ptr+i)" are used to access the elements of the dynamic array, but the difference is in the syntax. "ptr[i]" is an array subscript operator and "(ptr+i)" is pointer arithmetic.

What is the purpose of the line "delete[] ptr"?
The line "delete[] ptr" deallocates the memory that was previously allocated for the dynamic array using the new operator. This line is necessary to avoid memory leaks and to free up memory resources.

What is the purpose of the line "delete ptr1"?
The line "delete ptr1" deallocates the memory that was previously allocated for the integer object using the new operator. This line is necessary to avoid memory leaks and to free up memory resources.

What is the purpose of the "cout" statements in the code?
The "cout" statements in the code are used to display the elements of the dynamic array on the console. The statement "cout << "The elements of the dynamic array are: ";" outputs the message "The elements of the dynamic array are: ", and the statement "cout << ptr[i] << " ";" outputs the elements of the array separated by a space.

*/
int main()
{

    int x=5; //x and 5 are both on the stack
    int *ptr1=new int(); //ptr is on the stack and it contains an address on the heap to an int object

    int arr[]={1,2,3,4,5}; //arr and the array are both on the stack
    int n = 5; //n and 5 are both on the stack
    int *ptr = new int[n]; //ptr is on the stack, and the array of integers is on the heap
    for (int i = 0; i < n; i++) { //i and the values associated with it are on the stack
       //ptr[i] = i + 1; //the array on the heap is getting populated with the values
        *(ptr+i) = i + 1; //the array on the heap is getting populated with the values
    cout << "The elements of the dynamic array are: ";
  
    for (int i = 0; i < n; i++) { //i and the values associated with it are on the stack
        cout << ptr[i] << " ";
    }
    cout << endl;
    delete[] ptr; //deallocating the array from the heap
    delete ptr1; //deallocating the int from the heap
  }


    return 0;
    
}