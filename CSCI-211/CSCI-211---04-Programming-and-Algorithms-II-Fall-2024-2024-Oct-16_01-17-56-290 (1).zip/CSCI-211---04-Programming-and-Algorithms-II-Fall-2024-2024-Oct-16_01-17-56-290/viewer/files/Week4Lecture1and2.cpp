/*
The code implements a linked list in C++ using a Node class, which is nested inside the LinkedList class.

The Node class has three constructors: one default constructor, one constructor that takes in an integer value for the data and initializes the next pointer to nullptr, and one constructor that takes in an integer value for the data and a Node pointer for the next pointer.

The Node class has several public methods, including getData() to return the data stored in the node, getNext() to return the next node in the list, setNext(Node *n) to set the next node in the list, and a destructor to clean up the node when it's no longer needed.

The LinkedList class has several methods, including addData(int x) to add a new node to the list, remove() to remove the head node from the list, getSize() to return the number of nodes in the list, removeAllOccurrencesOf(int deleteItem) to remove all nodes with a specified value from the list, toString() to return a string representation of the list, and a destructor to clean up the list when it's no longer needed.

The addData(int x) method creates a new node with the specified value and adds it to the head of the list.

The remove() method removes the head node from the list and updates the head pointer to the next node in the list.

The getSize() method counts the number of nodes in the list by iterating through the list and following the next pointers.

The removeAllOccurrencesOf(int deleteItem) method removes all nodes with the specified value by iterating through the list and updating the pointers as needed.

The toString() method returns a string representation of the list by concatenating the data values of each node in the list.

The destructor for the LinkedList class cleans up the list by iterating through the list and deleting each node. The destructor for the Node class sets the next pointer to nullptr.

*/
#include<string>
#include<iostream>
using namespace std;

// Definition of the LinkedList class
class LinkedList
{
    // Definition of the Node class
    private: class Node
    {
        private:
            int data;   // variable to store the data in the node
            Node *next; // variable to store the reference to the next node

        public:
            // Default constructor for the Node class
            Node()
            {

            }
            // Constructor for the Node class with a single integer argument
            Node(int data)
            {
                this->data = data;
                this->next = nullptr;
            }
            // Constructor for the Node class with two arguments
            Node(int data, Node *next)
            {
                this->data = data;
                this->next = next;
            }
            // Function to get the data stored in the node
            int getData()
            {
                return data;
            }

            // Function to get the reference to the next node
            Node* getNext()
            {
                return next;
            }

            // Function to set the reference to the next node
            void setNext(Node* n)
            {
                next = n;
            }
            // Destructor for the node class
            ~Node()
            {
                cout <<"destructor of the node class called" <<endl;
                this->next = nullptr;
            }

    };

    private:
    // Pointer to the head node in the linked list
    Node *head;
    // Variable to store the size of the linked list
    int size;

    public:
    // Default constructor for the LinkedList class
    LinkedList();
    // Destructor for the LinkedList class
    ~LinkedList();
    // Function to add data to the linked list
    void addData(int x);
    // Function to remove the head node from the linked list
    void remove();
    // Function to get the size of the linked list
    int getSize();
    // Function to remove all occurrences of a specific integer value from the linked list
    void removeAllOccurancesOf(int deleteItem);
    // Function to convert the linked list to a string representation
    string toString();
};

// Default constructor for the LinkedList class
LinkedList::LinkedList()
{
    // Initialize the head pointer to null
    head = nullptr;
    // Initialize the size of the linked list to 0
    size = 0;
}

// Function to add data to the linked list
void LinkedList::addData(int x)
{
    // If the head pointer is null, create a new node with the data and set it as the head
    if (head == nullptr)
        head = new Node(x);
    else
        // If the head pointer is not null, create a new node with the data and set it as the new head, with the current head as its next node
        head = new Node(x, head);
    // Increase the size of the linked list by 1
    size = size + 1;
}

// Function to remove the head node from the linked list
void LinkedList::remove()
{
    // If the head pointer is not null
    if (head !=nullptr)
    {
    // Create a temporary pointer to the head node to be deleted
    Node* toDelete = head;
    // Set the head pointer to the next node in the linked list
    head = head->getNext();
    // Delete the head node
    delete toDelete;
    // Decrease the size of the linked list by 1
    size = size - 1;
    }
}

// Function to get the size of the linked list
int LinkedList::getSize()
{
    // Initialize a counter to 0
    int count = 0;
    // Create a temporary pointer to the head node
    Node* temp = head;
    // Iterate through the linked list until the end is reached
    while (temp != nullptr)
    {
        // Set the temporary pointer to the next node
        temp = temp->getNext();
        // Increase the counter by 1
        count++;
    }
    // Return the size of the linked list
    return count;
}

// Function to remove all occurrences of a specific integer value from the linked list
void LinkedList::removeAllOccurancesOf(int deleteItem)
{
    // Create pointers to the current node and the previous node
    Node* current = head;
    Node* prev = nullptr;
    // Iterate through the linked list until the end is reached
    while (current != nullptr)
    {
        // If the data in the current node is equal to the value to be deleted
        if (current->getData() == deleteItem)
        {
            // If the previous node is null (i.e., the head node is to be deleted)
            if (prev == nullptr)
            {
                // Create a temporary pointer to the head node to be deleted
                Node* toDelete = head;
                // Set the head pointer to the next node in the linked list
                head = head->getNext();
                // Delete the head node
                delete toDelete;
                // Set the current pointer to the new head node
                current = head;
                // Continue to the next iteration
                continue;
            }
            else
            {
                // If the previous node is not null, set its next pointer to the next node after the current node
                prev->setNext(current->getNext());
                // Delete the current node
                delete current;
                // Set the current pointer to the node after the previous node
                current = prev->getNext();
                // Continue to the next iteration
                continue;
            }
            // Decrease the size of the linked list by 1
            size = size - 1;
        }
        // Set the previous pointer to the current node
        prev = current;
        // Set the current pointer to the next node
        current = current->getNext();
    }
}

// Function to convert the linked list to a string representation
string LinkedList::toString()
{
    // Initialize an empty string to store the linked list representation
    string ret = "";
    // Create a temporary pointer to the head node
    Node *current = head;
    // Iterate through the linked list until the end is reached
    while (current != nullptr)
    {
        // Concatenate the data in the current node to the string representation
        ret = ret + to_string(current->getData()) + " ";
        // Set the current pointer to the next node
        current = current->getNext();
    }
    // Return the string representation of the linked list
    return ret;
}

// Destructor for the LinkedList class
LinkedList::~LinkedList()
{
    // Create pointers to the current node and the previous node
    Node *prev = nullptr;
    Node *current = head;
    // Iterate through the linked list until the end is reached
    while (current != nullptr)
    {
        // Delete the previous node
        delete prev;
        // Set the previous pointer to the current node
        prev = current;
        // Set the current pointer to the next node
        current = current->getNext();
    }
    // Delete the last node
    delete prev;
}

int main(void)
{

   
   LinkedList *l1 = new LinkedList();
   cout <<"Linked List is: " << l1->toString() <<endl;
   cout << "Size of the linked list is: " << l1->getSize() <<endl;
   l1->addData(1);
   l1->addData(2);
   l1->addData(3);
   l1->addData(4);
   l1->addData(5);
   l1->addData(5);
   l1->addData(5);
   l1->addData(6);
   l1->addData(6);
   l1->addData(6);
   l1->addData(6);
   l1->addData(7);
   l1->addData(8);
   cout <<"Linked List is: " << l1->toString() <<endl;
   cout << "Size of the linked list is: " << l1->getSize() <<endl;
   l1->remove();
   cout <<"Linked List is: " << l1->toString() <<endl;
   cout << "Size of the linked list is: " << l1->getSize() <<endl;
   l1->removeAllOccurancesOf(5);
   cout <<"Linked List is: " << l1->toString() <<endl;
   cout << "Size of the linked list is: " << l1->getSize() <<endl;   
   l1->removeAllOccurancesOf(7);
   cout <<"Linked List is: " << l1->toString() <<endl;
   cout << "Size of the linked list is: " << l1->getSize() <<endl;   

   l1->removeAllOccurancesOf(6);
   cout <<"Linked List is: " << l1->toString() <<endl;
   cout << "Size of the linked list is: " << l1->getSize() <<endl;   

   delete l1;
}

/*
What is the purpose of the Node class in the code?
The Node class is used to implement a node in a linked list. 
It has three constructors to initialize the node with data and next 
pointer, several public methods to get and set the data and next pointer 
in the node, and a destructor to clean up the node when it's no longer 
needed.

What is the purpose of the LinkedList class in the code?
The LinkedList class is used to implement a linked list. 
It has several methods to add and remove nodes from the list, 
get the size of the list, remove all occurrences of a specified value 
from the list, return a string representation of the list, and clean up 
the list when it's no longer needed.

What does the addData() method in the LinkedList class do?
The addData() method is used to add a new node with the specified 
value to the head of the linked list. If the head pointer is null, 
it creates a new node with the data and sets it as the head. If the 
head pointer is not null, it creates a new node with the data and sets 
it as the new head with the current head as its next node. It then 
increases the size of the linked list by 1.

What does the remove() method in the LinkedList class do?
The remove() method is used to remove the head node from the linked list. 
If the head pointer is not null, it creates a temporary pointer to the
 head node to be deleted, sets the head pointer to the next node in the
  linked list, deletes the head node, and decreases the size of the 
  linked list by 1.

What does the getSize() method in the LinkedList class do?
The getSize() method is used to get the size of the linked list. 
It initializes a counter to 0, creates a temporary pointer to the head 
node, and iterates through the linked list until the end is reached. 
For each node, it sets the temporary pointer to the next node and 
increases the counter by 1. Finally, it returns the size of the linked 
list.

What does the removeAllOccurrencesOf() method in the LinkedList class do?
The removeAllOccurrencesOf() method is used to remove all occurrences 
of a specified integer value from the linked list. It creates pointers to 
the current node and the previous node and iterates through the linked 
list until the end is reached. If the data in the current node is equal 
to the value to be deleted, it either deletes the head node or sets the 
next pointer of the previous node to the next node after the current node
 and deletes the current node. It then decreases the size of the linked 
 list by 1.

What is the purpose of the destructor in the LinkedList class?
The destructor in the LinkedList class is used to clean up the 
linked list when it's no longer needed. It creates pointers to the 
current node and the previous node, iterates through the linked list 
until the end is reached, deletes the previous node, sets the previous
 pointer to the current node, and sets the current pointer to the next 
 node. Finally, it deletes the last node.

*/