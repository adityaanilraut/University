#include <iostream>
#include <string>
using namespace std;
/*
Write a recursive function that determines whether a string is a palindrome.

*/
bool isPalindrome(const string& str, int start, int end) {
    if (start >= end) {
        return true;
    }
    if (str[start] != str[end]) {
        return false;
    }
    return isPalindrome(str, start + 1, end - 1);
}

int main() {
    string testStr = "racecar";
    if (isPalindrome(testStr, 0, testStr.length() - 1)) {
        cout << testStr << " is a palindrome" << endl;
    } else {
        cout << testStr << " is not a palindrome" << endl;
    }
    return 0;
}
