/*
Write a C++ function that finds the sum of every integer in the array 
*/
#include <iostream>
using namespace std;

int findSum(int arr[], int n) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += arr[i];
    }
    return sum;
}

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    int arr[n];
    cout << "Enter the elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int sum = findSum(arr, n);

    cout << "Sum of elements: " << sum << endl;
    return 0;
}
