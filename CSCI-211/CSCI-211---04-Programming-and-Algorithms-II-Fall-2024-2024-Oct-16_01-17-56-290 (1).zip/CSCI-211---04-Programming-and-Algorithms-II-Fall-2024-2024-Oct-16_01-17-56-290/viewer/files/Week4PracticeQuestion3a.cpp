/*
Suppose you have a C++ class called Employee 
that contains a name string and a salary integer, 
and you want to make sure that the salary 
of each employee is zeroed out when they are deleted. 
Write a destructor for this class that sets the salary 
to zero before deallocating the memory.
*/
#include <string>
using namespace std;

class Employee {
private:
  string name;
  int salary;
public:
  Employee(string n, int s) {
    name = n;
    salary = s;
  }
  ~Employee() {
    salary = 0;
  }
};
