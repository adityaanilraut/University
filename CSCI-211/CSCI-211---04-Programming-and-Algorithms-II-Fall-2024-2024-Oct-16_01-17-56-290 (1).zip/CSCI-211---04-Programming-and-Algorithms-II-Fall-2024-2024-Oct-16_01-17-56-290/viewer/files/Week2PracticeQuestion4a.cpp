/*
Write a C++ function that takes an integer as input and 
returns the sum of its digits.
*/

int sumOfDigits(int x) {
    int sum = 0;
    while (x != 0) {
        sum += x % 10;
        x /= 10;
    }
    return sum;
}


/*
you can have a main function with the following piece of code to test 
the above solution 

int num = 12345;
cout << sumOfDigits(num) << endl; // Output: 15

*/