/*
Suppose you have a C++ class called Stack 
that represents a stack of integers, 
implemented using a dynamically allocated array, 
with a top index pointing to the top of the stack. 
Write a destructor for this class that properly 
deallocates the memory for the array.
*/

class Stack {
private:
  int* data;
  int top;
public:
  Stack(int capacity) {
    data = new int[capacity];
    top = -1;
  }
  ~Stack() {
    delete[] data;
  }
};
