#include <iostream>
using namespace std;


/*
What does the "func" function do?
The "func" function takes a double pointer to int and an integer "n" as arguments, and it prints the elements of the integer array in reverse order.

What does the line "ptr[i] = &arr[i];" do?
This line stores the address of each element of the integer array "arr" into the array of pointers "ptr".

What is the difference between "int *ptr[5];" and "int **ptr"?
"int *ptr[5];" declares an array of pointers to integers, whereas "int **ptr" declares a double pointer to integer. The former holds the addresses of integer values, while the latter holds the address of an integer pointer.

What is the output of the program?
The output of the program is "5 4 3 2 1", which is the reverse of the original array "arr".

What is the purpose of the line "cout << sizeof(arr) <<endl;"?
The line "cout << sizeof(arr) <<endl;" outputs the size of the integer array "arr" in bytes.

What is the purpose of the line "cout << sizeof(ptr) <<endl;"?
The line "cout << sizeof(ptr) <<endl;" outputs the size of the array of pointers "ptr" in bytes.

What is the purpose of the line "cout << sizeof(void*)*8 <<endl;"?
The line "cout << sizeof(void*)*8 <<endl;" outputs the size of a pointer in bits. "void" is a generic pointer type, and multiplying its size by 8 gives the number of bits it takes to store the address.

*/
void func(int **ptr, int n) {
//void func(int *ptr[], int n) {
    for (int i = n-1; i >= 0; i--)
        cout << *ptr[i] << " ";
}

int main() {
    int arr[5] = {1, 2, 3, 4, 5};
    int *ptr[5];
    cout << sizeof(arr) <<endl;
    cout << sizeof(ptr) <<endl;
    cout << sizeof(void*)*8 <<endl;
    for (int i = 0; i < 5; i++)
        ptr[i] = &arr[i];
    func(ptr, 5);
    return 0;
}