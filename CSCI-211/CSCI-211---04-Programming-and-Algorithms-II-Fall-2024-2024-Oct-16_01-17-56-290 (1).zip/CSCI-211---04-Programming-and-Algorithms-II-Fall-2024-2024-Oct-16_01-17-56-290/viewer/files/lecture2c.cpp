#include <iostream>
/*
What does the line "int *heapArray = new int[n];" do in the code?
The line allocates n elements on the heap memory and creates a pointer heapArray which points to the first element of the dynamically allocated array.

What is the difference between heapArray and stackArray in the code?
heapArray is a dynamically allocated array on the heap memory while stackArray is a statically allocated array on the stack memory.

What is the purpose of the line "delete[] heapArray;" in the code?
The line frees the memory that was dynamically allocated for the heapArray using the operator 'new'. This is important to prevent memory leaks in the program.

What is the output of the code if n=3 and the values of heapArray and stackArray are [1,2,3] and [4,5,6] respectively?
The output of the code will be:
"The values of the heap array are: 1 2 3 "
"The values of the stack array are: 4 5 6 "

How does the stack memory and heap memory differ in terms of allocation and deallocation of memory?
The stack memory is used for statically allocated memory and is automatically managed by the program. The memory is allocated and deallocated in a last-in-first-out manner. On the other hand, the heap memory is used for dynamically allocated memory and is managed manually by the programmer. The memory can be allocated at any time and can be deallocated at any time, but it is the programmer's responsibility to keep track of the dynamically allocated memory and deallocate it when it is no longer needed to prevent memory leaks.

*/

using namespace std;
int main() {
  int n;
  cout << "Enter the size of the heap array: ";
  cin >> n;

  int *heapArray = new int[n];
  cout << "Enter the values of the heap array: ";
  for (int i = 0; i < n; i++) {
    cin >> heapArray[i];
  }

  int stackArray[n];
  cout << "Enter the values of the stack array: ";
  for (int i = 0; i < n; i++) {
    cin >> stackArray[i];
  }

  cout << "The values of the heap array are: ";
  for (int i = 0; i < n; i++) {
    cout << heapArray[i] << " ";
  }
  cout << endl;

  cout << "The values of the stack array are: ";
  for (int i = 0; i < n; i++) {
    cout << stackArray[i] << " ";
  }
  cout << endl;

  delete[] heapArray;
  return 0;
}
