#include <iostream>
using namespace std;
/*
Q1: What is the value of x2 when it is first declared in the code?

A1: The value of x2 is 'a'.

Q2: What is the address of x2?

A2: The address of x2 can be obtained by calling &x2.

Q3: What is the size of x2 in bytes?

A3: The size of x2 is 1 byte.

Q4: What is the value of x3?

A4: The value of x3 is a pointer that points to the address of x2.

Q5: What is the address of x3?

A5: The address of x3 can be obtained by calling &x3.

Q6: What are the values of arr[0], arr[1], arr[2], and arr[3] when the array arr is declared as a character array?

A6: The values of arr[0], arr[1], arr[2], and arr[3] are 'a', 'b', 'c', and 'd' respectively.

Q7: What are the addresses of arr[0], arr[1], arr[2], and arr[3] when arr is declared as a character array?

A7: The addresses of arr[0], arr[1], arr[2], and arr[3] can be obtained by calling arr, arr + 1, arr + 2, and arr + 3 respectively.

Q8: What are the values of arr[0], arr[1], arr[2], and arr[3] when the array arr is declared as a double array?

A8: The values of arr[0], arr[1], arr[2], and arr[3] are 1.2, 2.5, 3.4, and 4.2 respectively.

Q9: What are the addresses of arr[0], arr[1], arr[2], and arr[3] when arr is declared as a double array?

A9: The addresses of arr[0], arr[1], arr[2], and arr[3] can be obtained by calling arr, arr + 1, arr + 2, and arr + 3 respectively.
*/
int main()
{
    char x2='a';
    printf ("The value of x2 is %c\n",x2);
    printf ("The address of x2 is %p\n",&x2);
    printf ("The sizeof of x2 is %i bytes\n",sizeof(x2));
    char *x3=&x2;
    printf ("The value of x3 is %p\n",x3);
    printf ("The address of x3 is %p\n",&x3);

    char arr[]={'a','b','c','d'};
    printf("The value of arr[0] is %c\n",arr[0]);
    printf("The value of arr[1] is %c\n",arr[1]);
    printf("The value of arr[2] is %c\n",arr[2]);
    printf("The value of arr[3] is %c\n",arr[3]);

    printf("The address of arr[0] is %p\n",arr);
    printf("The address of arr[1] is %p\n",arr+1);
    printf("The address of arr[2] is %p\n",arr+2);
    printf("The address of arr[3] is %p\n",arr+3);



    cout << "-------------" <<endl;

    


    double arr1[]={1.2,2.5,3.4,4.2};
    printf("The value of arr1[0] is %f\n",*arr1);
    printf("The value of arr1[1] is %f\n",*(arr1+1));
    printf("The value of arr1[2] is %f\n",*(arr1+2));
    printf("The value of arr1[3] is %f\n",*(arr1+3));

    printf("The address of arr1[0] is %p\n",arr1);
    printf("The address of arr1[1] is %p\n",arr1+1);
    printf("The address of arr1[2] is %p\n",arr1+2);
    printf("The address of arr1[3] is %p\n",arr1+3);

    return 0;
}