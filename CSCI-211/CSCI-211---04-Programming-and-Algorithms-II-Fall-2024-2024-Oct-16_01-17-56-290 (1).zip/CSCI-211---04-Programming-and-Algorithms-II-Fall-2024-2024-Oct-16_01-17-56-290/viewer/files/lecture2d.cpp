#include <iostream>
using namespace std;

/*
What does the arrayOfPointers variable represent in the code?
The arrayOfPointers variable is a pointer to an array of integer pointers. It is used to store a dynamically allocated array of integer pointers.

What is the purpose of the first loop in the code?
The first loop in the code is used to dynamically allocate memory for n integer values and store the address of each allocation in the arrayOfPointers array.

What is the purpose of the second loop in the code?
The second loop in the code is used to print the values of the n dynamically allocated integer variables, which are pointed to by the pointers stored in the arrayOfPointers array.

Why is delete used in the code and what does it do?
The delete keyword is used in the code to deallocate dynamically allocated memory. In the code, delete is used to free up the memory previously allocated for the n integer variables.

Why is delete[] used in the code and what does it do?
The delete[] keyword is used in the code to deallocate dynamically allocated memory for an array. In the code, delete[] is used to free up the memory previously allocated for the arrayOfPointers array.

What is the output of the code when n=3 and the user inputs 5, 6, 7 for the values of the pointers?
The output of the code when n=3 and the user inputs 5, 6, 7 for the values of the pointers would be: "The values of the pointers are: 5 6 7".

*/
int main() {
  int n;
  cout << "Enter the size of the array: ";
  cin >> n;

  int **arrayOfPointers = new int*[n];
  for (int i = 0; i < n; i++) {
    arrayOfPointers[i] = new int;
    cout << "Enter the value for the " << i + 1 << "th pointer: ";
    cin >> *arrayOfPointers[i];
  }

  cout << "The values of the pointers are: ";
  for (int i = 0; i < n; i++) {
    cout << *arrayOfPointers[i] << " ";
  }
  cout << endl;

  for (int i = 0; i < n; i++) {
    delete arrayOfPointers[i];
  }
  delete[] arrayOfPointers;
  return 0;
}
