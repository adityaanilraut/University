#include <iostream>
using namespace std;

class ArrayStack {
private:
    int* data;      // dynamic array to store the elements of the stack
    int head;       // index of the top element in the stack
    int capacity;   // maximum capacity of the stack
public:
    ArrayStack(int cap) {
        capacity = cap;
        data = new int[cap];    // allocate memory for the dynamic array
        head = -1;              // initialize the index of the top element to -1
    }
    ~ArrayStack() {
        delete[] data;          // free the memory used by the dynamic array
    }
    void push(int x) {
        if (head < capacity-1) {        // check if the stack is not already full
            head++;                     // increment the index of the top element
            data[head] = x;             // add the new element to the top of the stack
        }
    }
    void pop() {
        if (head >= 0) {                // check if the stack is not already empty
            head--;                     // decrement the index of the top element
        }
    }
    int top() {
        if (head >= 0) {                // check if the stack is not empty
            return data[head];          // return the value of the top element
        }
        return 0;                       // return 0 if the stack is empty
    }
};

int main() {
    ArrayStack *as = new ArrayStack(5); // create a new stack with maximum capacity of 5
    
    as->push(1);        // add elements to the stack
    as->push(2);
    as->push(3);
    as->push(4);
    as->push(5);
    
    cout << as->top() << endl;      // print the value of the top element
    
    as->pop();                      // remove elements from the stack
    cout << as->top() << endl;
    
    as->pop();
    cout << as->top() << endl;
    
    as->pop();
    cout << as->top() << endl;
    
    as->pop();
    cout << as->top() << endl;
    
    delete as;                      // free the memory used by the stack
    
    return 0;
}


/*
What is the purpose of the ArrayStack class?
Solution: The ArrayStack class is used to implement a stack data structure using a dynamic array.

What are the private member variables of the ArrayStack class?
Solution: The private member variables are data, which is a dynamic array to store the elements of the stack, head, which is the index of the top element in the stack, and capacity, which is the maximum capacity of the stack.

What is the purpose of the ArrayStack constructor?
Solution: The constructor initializes the capacity member variable to the value passed as an argument, allocates memory for the dynamic array data, and sets the head member variable to -1.

What is the purpose of the ~ArrayStack destructor?
Solution: The destructor frees up the memory used by the dynamic array data.

What is the purpose of the push method of the ArrayStack class?
Solution: The push method adds a new element to the top of the stack, provided that the stack is not already full.

What is the purpose of the pop method of the ArrayStack class?
Solution: The pop method removes the top element from the stack, provided that the stack is not already empty.

What is the purpose of the top method of the ArrayStack class?
Solution: The top method returns the value of the top element in the stack, provided that the stack is not empty.

What is the purpose of the main function?
Solution: The main function creates a new ArrayStack object with a maximum capacity of 5, pushes 5 elements onto the stack, pops some elements off the stack, and prints the value of the top element after each operation.

What happens if you try to push an element onto a full stack?
Solution: If you try to push an element onto a full stack, the push method will not add the new element to the stack.

What happens if you try to pop an element off an empty stack?
Solution: If you try to pop an element off an empty stack, the pop method will not remove any element from the stack.

*/