/*
Suppose you have a C++ class called Image that 
represents a bitmap image, 
with width and height being its dimensions. 
Write a destructor for this class that frees 
up the memory allocated for the image data.
*/

class Image {
private:
  int width, height;
  char* imageData;
public:
  Image(int w, int h) {
    width = w;
    height = h;
    imageData = new char[w*h];
  }
  ~Image() {
    delete[] imageData;
  }
};
