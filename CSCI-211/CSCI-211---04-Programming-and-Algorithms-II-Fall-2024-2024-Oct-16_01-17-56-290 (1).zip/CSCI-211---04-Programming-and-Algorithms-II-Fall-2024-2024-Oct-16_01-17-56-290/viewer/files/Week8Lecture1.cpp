#include <stack>
#include <string>
#include <iostream>
using namespace std;

// Determines the precedence of an operator
int precedence(char op) {
    if (op == '+' || op == '-') {
        return 1;
    } else if (op == '*' || op == '/') {
        return 2;
    } else {
        return 0;
    }
}

// Checks if a character is an operator
bool isOperator(char c) {
    return c == '+' || c == '-' || c == '*' || c == '/';
}

// Converts an infix expression to a postfix expression
string infixToPostfix(const string infix) {
    stack<char> stack; // Stack for holding operators and parentheses
    string postfix; // Output postfix expression

    // Loop through each character in the infix expression
    for (char c : infix) {
        // Ignore whitespace
        if (isspace(c)) {
            continue;
        }

        // If the character is alphanumeric, add it to the postfix expression
        if (isalnum(c)) {
            postfix += c;
        }
        // If the character is an opening parenthesis, push it onto the stack
        else if (c == '(') {
            stack.push(c);
        }
        // If the character is a closing parenthesis, pop operators from the stack and add them to the postfix expression until an opening parenthesis is encountered
        else if (c == ')') {
            while (!stack.empty() && stack.top() != '(') {
                postfix += stack.top();
                stack.pop();
            }

            // Pop the opening parenthesis from the stack
            stack.pop();
        }
        // If the character is an operator, pop operators with higher or equal precedence from the stack and add them to the postfix expression, then push the current operator onto the stack
        else if (isOperator(c)) {
            while (!stack.empty() && precedence(c) <= precedence(stack.top())) {
                postfix += stack.top();
                stack.pop();
            }
            stack.push(c);
        }
        // If the character is not a valid operator or parenthesis, throw an error
        else {
            //for now doing nothing here. 
        }
    }

    // Pop any remaining operators from the stack and add them to the postfix expression
    while (!stack.empty()) {
        postfix += stack.top();
        stack.pop();
    }

    return postfix;
}

// Main function to test the infix to postfix conversion
int main() {
    //we are assuming that the infix strings are always well formed. 
    //there is no error checking happening in this code for example of malformed infix strings. 
    string infix="A*B+C";
    string postfix = infixToPostfix(infix);
    cout << "Postfix expression: " << postfix << endl;
    return 0;
}
