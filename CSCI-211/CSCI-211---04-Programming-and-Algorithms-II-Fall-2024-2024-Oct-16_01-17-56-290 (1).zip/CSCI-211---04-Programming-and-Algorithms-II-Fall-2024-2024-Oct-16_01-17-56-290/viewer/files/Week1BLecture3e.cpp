#include <iostream>
using namespace std;

/*
What does the copyArray function do?
The copyArray function copies the elements of one array, arr1, to another array, arr2.

How does the function copyArray work?
The function copyArray works by using two pointers, arr2 and ptr, to traverse both arrays arr1 and arr2 respectively. For each iteration, the value pointed to by ptr is copied to the location pointed to by arr2, and both pointers are incremented. The loop continues until ptr reaches the end of the arr1 array, which is indicated by the condition ptr <= endptr.

What is the purpose of the endptr pointer in the function copyArray?
The endptr pointer is used to keep track of the end of the arr1 array. The loop in copyArray continues until ptr reaches endptr, at which point the function terminates and all elements of arr1 have been copied to arr2.

Can you write a similar function that copies elements from arr2 to arr1?
Yes, the following function copies elements from arr2 to arr1:

void copyArrayBack(int *arr1, int *arr2, int n) {
  int *endptr = arr2+(n-1);
  for (int *ptr=arr2;ptr<=endptr; ptr++, arr1++)
  {
    *arr1=*ptr;
  }
}


*/

void copyArray(int *arr1, int *arr2, int n) {
  int *endptr = arr1+(n-1);
  for (int *ptr=arr1;ptr<=endptr; ptr++, arr2++)
  {
    *arr2=*ptr;
  }



}

int main() {
  int arr1[] = {1, 2, 3, 4, 5};
  int n = sizeof(arr1)/sizeof(arr1[0]);
  int arr2[n]; //
  copyArray(arr1, arr2, n);
  cout << "Copied array: ";
  for (int i = 0; i < n; i++) {
    cout << arr2[i] << " ";
  }
  cout << endl;
  return 0;
}