/*
Write a C++ class called Person that contains a dynamically allocated name string, and implement a destructor for it that properly deallocates the memory.
*/
#include <string>
using namespace std;

class Person {
private:
  string* name;
public:
  Person(string n) {
    name = new string(n);
  }
  ~Person() {
    delete name;
  }
};
