/*
Implement a class "Complex" that represents a complex number. 
The class should have two private data members "real" and "imag" 
that represent the real and imaginary parts of the complex number, 
respectively. 
The class should have a constructor that takes two arguments and 
initializes the data members, and two member functions "add" and 
"subtract" that perform addition and subtraction of two complex numbers, 
respectively. 
The class should also have a member function "display" that 
displays the complex number in the form "real + imag i".
*/

#include <iostream>

class Complex
{
    float real, imag;

public:
    Complex(float r, float i)
    {
        real = r;
        imag = i;
    }

    Complex add(Complex c)
    {
        return Complex(real + c.real, imag + c.imag);
    }

    Complex subtract(Complex c)
    {
        return Complex(real - c.real, imag - c.imag);
    }

    void display()
    {
        std::cout << real << " + " << imag << "i" << std::endl;
    }
};

int main()
{
    float r1, i1, r2, i2;

    std::cout << "Enter real and imaginary parts of first complex number: ";
    std::cin >> r1 >> i1;
    Complex *c1 = new Complex(r1, i1);

    std::cout << "Enter real and imaginary parts of second complex number: ";
    std::cin >> r2 >> i2;
    Complex *c2 = new Complex(r2, i2);

    Complex *sum = new Complex(0, 0);
    *sum = c1->add(*c2);
    std::cout << "Sum: ";
    sum->display();

    Complex *diff = new Complex(0, 0);
    *diff = c1->subtract(*c2);
    std::cout << "Difference: ";
    diff->display();

    delete c1, c2, sum, diff;

    return 0;
}
