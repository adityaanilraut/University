#ifndef SQUAREH
#define SQUAREH
#include "Shape.h"
class Square : public Shape {
public:
    void draw() const override {
        cout << "Drawing a square" << endl;
    }
};
#endif