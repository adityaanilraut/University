#include <queue>
#include <iostream>
using namespace std;

class BinaryTree
{
    public:
    BinaryTree()
    {
        root=nullptr;
    }
    private: 
    class Node
    {
        public:
        int data;
        Node* left;
        Node* right;

        public:
        Node(int d, Node*l, Node* r)
        {
            data=d;
            left=l;
            right=r;
        }

        void addDataInNode(int d)
        {
                
                queue<Node*>  q;
                q.push(this); //this is refering to the root node of the binary tree
                while(!q.empty())
                {
                    Node* n = q.front();
                    q.pop();
                    if (n->left==nullptr)
                    {
                        cout << "Parent Node:" << n->data <<endl;
                        cout << "Child Node inserted at left is :" << d <<endl;
                        n->left=new Node (d,nullptr,nullptr);
                        break;
                    }
                    if (n->right==nullptr)
                    {
                        cout << "Parent Node:" << n->data <<endl;
                        cout << "Child Node inserted at right is  :" << d <<endl;
                       n->right=new Node (d,nullptr,nullptr);
                       break;
                    }
                    q.push(n->left);
                    q.push(n->right);
                }

        }
    };

    Node* root;

    public:
    void addData(int d)
    {
        if (root==nullptr)
        {
            root=new Node (d,nullptr,nullptr);
        }
        else
        {
            root->addDataInNode(d);
        }
        

    }

    void __printPreOrder(Node* r,int depth)
    {
            if (r==nullptr)
            {
                return;
            }
            int index=0;
            string ret="";
            while(index<depth)
            {
                ret=ret+" ";
                index++;
            }
            cout << ret << r->data <<endl;
            __printPreOrder(r->left,depth+1);
            __printPreOrder(r->right,depth+1);
    }

    void printPreOrder()
    {
        if (root==nullptr)
        {
            return;
        }
        else
        {
            __printPreOrder(root,0);
        }
    }

    void __printPostOrder(Node* r,int depth)
    {
            if (r==nullptr)
            {
                return;
            }
            int index=0;
            string ret="";
            while(index<depth)
            {
                ret=ret+" ";
                index++;
            }
            __printPostOrder(r->left,depth+1);
            __printPostOrder(r->right,depth+1);
            cout << ret<< r->data <<endl;
    }

    void printPostOrder()
    {
        if (root==nullptr)
        {
            return;
        }
        else
        {
            __printPostOrder(root,0);
        }
    }

    void printLevelOrder()
    {
        if (root==nullptr)
            return;
        else
        {
            queue<Node*> q; 
            q.push(root);

            while(q.size()!=0)
            {

            Node* toPrint=q.front();
            cout << toPrint->data <<endl;
            q.pop();
            if (toPrint->left!=nullptr)
                q.push(toPrint->left);
            if (toPrint->right!=nullptr)    
                q.push(toPrint->right);

            }

        }


    }

    int __additionOfNodesInBinaryTree(Node* r)
    {
        if (r==nullptr)
            return 0;
        else 
            return __additionOfNodesInBinaryTree(r->left)+__additionOfNodesInBinaryTree(r->right)+r->data;
    }
    int additionOfNodesInBinaryTree()
    {
        if (root==nullptr)
        {
            throw ("Cannot sum an empty binary Tree");

        }
        else
        {
                return __additionOfNodesInBinaryTree(root);
        }
    }

};

int main()
{
    BinaryTree *bt = new BinaryTree();
    bt->addData(1); 
    

    cout << "About to call printPreOrder" <<endl;
    bt->printPreOrder();

    cout << "About to call printPostOrder" <<endl;
    bt->printPostOrder();

    cout << "About to call level order printing" <<endl;
    bt->printLevelOrder();

    cout << "About to call addition of every node in a binaryTree" <<endl;
    cout <<"The summation of a binary tree is " << bt->additionOfNodesInBinaryTree() <<endl;
}