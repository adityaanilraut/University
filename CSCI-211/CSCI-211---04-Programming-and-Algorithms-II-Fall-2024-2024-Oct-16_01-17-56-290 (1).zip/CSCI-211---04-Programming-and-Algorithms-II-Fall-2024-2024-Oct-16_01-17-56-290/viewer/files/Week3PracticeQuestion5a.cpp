/*
Implement a class "Rectangle" that has two private data members 
"length" and "width". 
The class should have a constructor that takes two arguments and 
initializes the data members, 
and two member functions "getArea" and "getPerimeter" 
that return the area and perimeter of the rectangle, respectively. 
Create an array of pointers to "Rectangle" objects and initialize 
it with rectangles of different lengths and widths.
*/

#include <iostream>

class Rectangle
{
    int length, width;

public:
    Rectangle(int l, int w)
    {
        length = l;
        width = w;
    }

    int getArea()
    {
        return length * width;
    }

    int getPerimeter()
    {
        return 2 * (length + width);
    }
};

int main()
{
    Rectangle *rectangles[3];
    rectangles[0] = new Rectangle(2, 3);
    rectangles[1] = new Rectangle(4, 5);
    rectangles[2] = new Rectangle(6, 7);

    for (int i = 0; i < 3; i++)
    {
        std::cout << "Rectangle " << i + 1 << std::endl;
        std::cout << "Area: " << rectangles[i]->getArea() << std::endl;
        std::cout << "Perimeter: " << rectangles[i]->getPerimeter() << std::endl;
        std::cout << std::endl;
    }

    // Deallocate memory
    for (int i = 0; i < 3; i++)
    {
        delete rectangles[i];
    }

    return 0;
}
